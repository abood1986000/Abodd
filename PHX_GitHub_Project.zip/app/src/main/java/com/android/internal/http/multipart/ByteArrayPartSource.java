package com.android.internal.http.multipart;

import java.io.InputStream;

public class ByteArrayPartSource implements PartSource {
    public ByteArrayPartSource(String fileName, byte[] bytes) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public long getLength() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getFileName() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public InputStream createInputStream() {
        throw new RuntimeException("Stub!");
    }
}
