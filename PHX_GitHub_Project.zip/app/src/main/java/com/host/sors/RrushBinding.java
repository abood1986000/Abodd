package com.host.sors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public final class RrushBinding {
    public final Button button1;
    public final EditText edittext1;
    public final LinearLayout linear1;
    public final LinearLayout linear2;
    public final LinearLayout rootView;

    private RrushBinding(LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, EditText editText, Button button) {
        this.rootView = linearLayout;
        this.linear1 = linearLayout2;
        this.linear2 = linearLayout3;
        this.edittext1 = editText;
        this.button1 = button;
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static RrushBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static RrushBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.rrush, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static RrushBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear1);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear2);
        EditText editText = (EditText) findChildViewById(view, R.id.edittext1);
        Button button = (Button) findChildViewById(view, R.id.button1);
        if (linearLayout2 == null || linearLayout3 == null || editText == null || button == null) {
            throw new IllegalStateException("Required views are missing");
        }
        return new RrushBinding(linearLayout, linearLayout2, linearLayout3, editText, button);
    }

    private static <T extends View> View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }
}
