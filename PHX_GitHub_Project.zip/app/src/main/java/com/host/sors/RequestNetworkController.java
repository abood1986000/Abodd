package com.host.sors;

import com.google.gson.Gson;
import com.host.sors.RequestNetwork;
import java.io.IOException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RequestNetworkController {
    public static final String DELETE = "DELETE";
    public static final String GET = "GET";
    public static final String POST = "POST";
    public static final String PUT = "PUT";
    private static final int READ_TIMEOUT = 25000;
    public static final int REQUEST_BODY = 1;
    public static final int REQUEST_PARAM = 0;
    private static final int SOCKET_TIMEOUT = 15000;
    private static RequestNetworkController mInstance;
    protected OkHttpClient client;

    public static synchronized RequestNetworkController getInstance() {
        if (mInstance == null) {
            mInstance = new RequestNetworkController();
        }
        return mInstance;
    }

    private OkHttpClient getClient() {
        if (this.client == null) {
            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            try {
                TrustManager[] trustManagerArr = {new 1()};
                SSLContext sSLContext = SSLContext.getInstance("TLS");
                sSLContext.init(null, trustManagerArr, new SecureRandom());
                builder.sslSocketFactory(sSLContext.getSocketFactory(), (X509TrustManager) trustManagerArr[0]);
                builder.connectTimeout(15000L, TimeUnit.MILLISECONDS);
                builder.readTimeout(25000L, TimeUnit.MILLISECONDS);
                builder.writeTimeout(25000L, TimeUnit.MILLISECONDS);
                builder.hostnameVerifier(new 2());
            } catch (Exception e) {
            }
            this.client = builder.build();
        }
        return this.client;
    }

    class 1 implements X509TrustManager {
        1() {
        }

        @Override
        public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }

    class 2 implements HostnameVerifier {
        2() {
        }

        @Override
        public boolean verify(String str, SSLSession sSLSession) {
            return true;
        }
    }

    public void execute(RequestNetwork requestNetwork, String str, String str2, String str3, RequestNetwork.RequestListener requestListener) {
        Request.Builder builder = new Request.Builder();
        Headers.Builder builder2 = new Headers.Builder();
        if (requestNetwork.getHeaders().size() > 0) {
            for (Map.Entry entry : requestNetwork.getHeaders().entrySet()) {
                builder2.add((String) entry.getKey(), String.valueOf(entry.getValue()));
            }
        }
        try {
            if (requestNetwork.getRequestType() == 0) {
                if (str.equals(GET)) {
                    try {
                        HttpUrl.Builder builderNewBuilder = HttpUrl.parse(str2).newBuilder();
                        if (requestNetwork.getParams().size() > 0) {
                            for (Map.Entry entry2 : requestNetwork.getParams().entrySet()) {
                                builderNewBuilder.addQueryParameter((String) entry2.getKey(), String.valueOf(entry2.getValue()));
                            }
                        }
                        builder.url(builderNewBuilder.build()).headers(builder2.build()).get();
                    } catch (NullPointerException e) {
                        throw new NullPointerException("unexpected url: " + str2);
                    }
                } else {
                    FormBody.Builder builder3 = new FormBody.Builder();
                    if (requestNetwork.getParams().size() > 0) {
                        for (Map.Entry entry3 : requestNetwork.getParams().entrySet()) {
                            builder3.add((String) entry3.getKey(), String.valueOf(entry3.getValue()));
                        }
                    }
                    builder.url(str2).headers(builder2.build()).method(str, builder3.build());
                }
            } else {
                RequestBody requestBodyCreate = RequestBody.create(MediaType.parse("application/json"), new Gson().toJson(requestNetwork.getParams()));
                if (str.equals(GET)) {
                    builder.url(str2).headers(builder2.build()).get();
                } else {
                    builder.url(str2).headers(builder2.build()).method(str, requestBodyCreate);
                }
            }
            getClient().newCall(builder.build()).enqueue(new 3(requestNetwork, requestListener, str3));
        } catch (Exception e2) {
            requestListener.onErrorResponse(str3, e2.getMessage());
        }
    }

    class 3 implements Callback {
        private final RequestNetwork.RequestListener val$requestListener;
        private final RequestNetwork val$requestNetwork;
        private final String val$tag;

        3(RequestNetwork requestNetwork, RequestNetwork.RequestListener requestListener, String str) {
            this.val$requestNetwork = requestNetwork;
            this.val$requestListener = requestListener;
            this.val$tag = str;
        }

        class 1 implements Runnable {
            private final IOException val$e;
            private final RequestNetwork.RequestListener val$requestListener;
            private final String val$tag;

            1(RequestNetwork.RequestListener requestListener, String str, IOException iOException) {
                this.val$requestListener = requestListener;
                this.val$tag = str;
                this.val$e = iOException;
            }

            @Override
            public void run() {
                this.val$requestListener.onErrorResponse(this.val$tag, this.val$e.getMessage());
            }
        }

        public void onFailure(Call call, IOException iOException) {
            this.val$requestNetwork.getActivity().runOnUiThread(new 1(this.val$requestListener, this.val$tag, iOException));
        }

        class 2 implements Runnable {
            private final RequestNetwork.RequestListener val$requestListener;
            private final Response val$response;
            private final String val$responseBody;
            private final String val$tag;

            2(Response response, RequestNetwork.RequestListener requestListener, String str, String str2) {
                this.val$response = response;
                this.val$requestListener = requestListener;
                this.val$tag = str;
                this.val$responseBody = str2;
            }

            @Override
            public void run() {
                Headers headers = this.val$response.headers();
                HashMap map = new HashMap();
                for (String str : headers.names()) {
                    map.put(str, headers.get(str) != null ? headers.get(str) : "null");
                }
                this.val$requestListener.onResponse(this.val$tag, this.val$responseBody, map);
            }
        }

        public void onResponse(Call call, Response response) throws IOException {
            this.val$requestNetwork.getActivity().runOnUiThread(new 2(response, this.val$requestListener, this.val$tag, response.body().string().trim()));
        }
    }
}
