package com.host.sors;

import android.app.Activity;
import java.util.HashMap;

public class RequestNetwork {
    private Activity activity;
    private HashMap params = new HashMap();
    private HashMap headers = new HashMap();
    private int requestType = 0;

    public interface RequestListener {
        void onErrorResponse(String str, String str2);

        void onResponse(String str, String str2, HashMap map);
    }

    public RequestNetwork(Activity activity) {
        this.activity = activity;
    }

    public void setHeaders(HashMap map) {
        this.headers = map;
    }

    public void setParams(HashMap map, int i) {
        this.params = map;
        this.requestType = i;
    }

    public HashMap getParams() {
        return this.params;
    }

    public HashMap getHeaders() {
        return this.headers;
    }

    public Activity getActivity() {
        return this.activity;
    }

    public int getRequestType() {
        return this.requestType;
    }

    public void startRequestNetwork(String str, String str2, String str3, RequestListener requestListener) {
        RequestNetworkController.getInstance().execute(this, str, str2, str3, requestListener);
    }
}
