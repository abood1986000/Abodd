package com.host.sors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class PessBinding {
    public final Button Send;
    public final EditText email;
    public final LinearLayout linear1;
    public final LinearLayout linear2;
    public final LinearLayout linear3;
    public final TextView message;
    public final LinearLayout rootView;
    public final TextView textview1;
    public final TextView textview2;

    private PessBinding(LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, TextView textView, EditText editText, TextView textView2, Button button, LinearLayout linearLayout4, TextView textView3) {
        this.rootView = linearLayout;
        this.linear1 = linearLayout2;
        this.linear2 = linearLayout3;
        this.textview1 = textView;
        this.email = editText;
        this.textview2 = textView2;
        this.Send = button;
        this.linear3 = linearLayout4;
        this.message = textView3;
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static PessBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static PessBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.pess, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static PessBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear1);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear2);
        TextView textView = (TextView) findChildViewById(view, R.id.textview1);
        EditText editText = (EditText) findChildViewById(view, R.id.email);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview2);
        Button button = (Button) findChildViewById(view, R.id.Send);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear3);
        TextView textView3 = (TextView) findChildViewById(view, R.id.message);
        if (linearLayout2 == null || linearLayout3 == null || textView == null || editText == null || textView2 == null || button == null || linearLayout4 == null || textView3 == null) {
            throw new IllegalStateException("Required views are missing");
        }
        return new PessBinding(linearLayout, linearLayout2, linearLayout3, textView, editText, textView2, button, linearLayout4, textView3);
    }

    private static <T extends View> View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }
}
