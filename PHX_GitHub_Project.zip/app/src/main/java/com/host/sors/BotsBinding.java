package com.host.sors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class BotsBinding {
    public final ImageView Copy;
    public final ImageView Delete;
    public final ImageView WebHook;
    public final ImageView editer;
    public final ImageView imageview1;
    public final LinearLayout linear1;
    public final LinearLayout linear2;
    public final LinearLayout linear3;
    public final LinearLayout linear4;
    public final LinearLayout rootView;
    public final TextView textview1;
    public final TextView textview2;

    private BotsBinding(LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, ImageView imageView, LinearLayout linearLayout4, TextView textView, LinearLayout linearLayout5, TextView textView2, ImageView imageView2, ImageView imageView3, ImageView imageView4, ImageView imageView5) {
        this.rootView = linearLayout;
        this.linear1 = linearLayout2;
        this.linear2 = linearLayout3;
        this.imageview1 = imageView;
        this.linear3 = linearLayout4;
        this.textview1 = textView;
        this.linear4 = linearLayout5;
        this.textview2 = textView2;
        this.WebHook = imageView2;
        this.editer = imageView3;
        this.Copy = imageView4;
        this.Delete = imageView5;
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static BotsBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static BotsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.bots, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static BotsBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear1);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear2);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imageview1);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear3);
        TextView textView = (TextView) findChildViewById(view, R.id.textview1);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear4);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview2);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.WebHook);
        ImageView imageView3 = (ImageView) findChildViewById(view, R.id.editer);
        ImageView imageView4 = (ImageView) findChildViewById(view, R.id.Copy);
        ImageView imageView5 = (ImageView) findChildViewById(view, R.id.Delete);
        if (linearLayout2 == null || linearLayout3 == null || imageView == null || linearLayout4 == null || textView == null || linearLayout5 == null || textView2 == null || imageView2 == null || imageView3 == null || imageView4 == null || imageView5 == null) {
            throw new IllegalStateException("Required views are missing");
        }
        return new BotsBinding(linearLayout, linearLayout2, linearLayout3, imageView, linearLayout4, textView, linearLayout5, textView2, imageView2, imageView3, imageView4, imageView5);
    }

    private static <T extends View> View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }
}
