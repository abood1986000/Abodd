package com.host.sors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;

public final class TokenBinding {
    public final AppBarLayout AppBar;
    public final CoordinatorLayout Coordinator;
    public final Toolbar Toolbar;
    public final Button button1;
    public final EditText edittext1;
    public final LinearLayout linear1;
    public final LinearLayout linear2;
    public final LinearLayout linear3;
    public final TextView textview1;

    private TokenBinding(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Toolbar toolbar, LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, EditText editText, Button button, TextView textView) {
        this.Coordinator = coordinatorLayout;
        this.AppBar = appBarLayout;
        this.Toolbar = toolbar;
        this.linear1 = linearLayout;
        this.linear2 = linearLayout2;
        this.linear3 = linearLayout3;
        this.edittext1 = editText;
        this.button1 = button;
        this.textview1 = textView;
    }

    public CoordinatorLayout getRoot() {
        return this.Coordinator;
    }

    public static TokenBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static TokenBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.token, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static TokenBinding bind(View view) {
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) view;
        AppBarLayout appBarLayoutFindChildViewById = findChildViewById(view, R.id._app_bar);
        Toolbar toolbarFindChildViewById = findChildViewById(view, R.id._toolbar);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear1);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear2);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear3);
        EditText editText = (EditText) findChildViewById(view, R.id.edittext1);
        Button button = (Button) findChildViewById(view, R.id.button1);
        TextView textView = (TextView) findChildViewById(view, R.id.textview1);
        if (appBarLayoutFindChildViewById == null || toolbarFindChildViewById == null || linearLayout == null || linearLayout2 == null || linearLayout3 == null || editText == null || button == null || textView == null) {
            throw new IllegalStateException("Required views are missing");
        }
        return new TokenBinding(coordinatorLayout, appBarLayoutFindChildViewById, toolbarFindChildViewById, linearLayout, linearLayout2, linearLayout3, editText, button, textView);
    }

    private static <T extends View> View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }
}
