package com.host.sors;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.host.sors.RequestNetwork;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class TokenActivity extends AppCompatActivity {
    private RequestNetwork.RequestListener _req_post_token_request_listener;
    private TokenBinding binding;
    private SharedPreferences data;
    private RequestNetwork req_post_token;
    private HashMap map_token = new HashMap();
    private HashMap map_json = new HashMap();
    private Intent i = new Intent();

    static TokenBinding access$0(TokenActivity tokenActivity) {
        return tokenActivity.binding;
    }

    static void access$1(TokenActivity tokenActivity, HashMap map) {
        tokenActivity.map_token = map;
    }

    static HashMap access$2(TokenActivity tokenActivity) {
        return tokenActivity.map_token;
    }

    static HashMap access$4(TokenActivity tokenActivity) {
        return tokenActivity.map_json;
    }

    static void access$6(TokenActivity tokenActivity, HashMap map) {
        tokenActivity.map_json = map;
    }

    static SharedPreferences access$7(TokenActivity tokenActivity) {
        return tokenActivity.data;
    }

    static RequestNetwork access$3(TokenActivity tokenActivity) {
        return tokenActivity.req_post_token;
    }

    static RequestNetwork.RequestListener access$5(TokenActivity tokenActivity) {
        return tokenActivity._req_post_token_request_listener;
    }

    static Intent access$8(TokenActivity tokenActivity) {
        return tokenActivity.i;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = TokenBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        setSupportActionBar(this.binding.Toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this.binding.Toolbar.setNavigationOnClickListener(new 1());
        this.data = getSharedPreferences("data", 0);
        this.req_post_token = new RequestNetwork(this);
        this.binding.button1.setOnClickListener(new 2());
        this._req_post_token_request_listener = new 3();
    }

    class 1 implements View.OnClickListener {
        1() {
        }

        @Override
        public void onClick(View view) {
            TokenActivity.this.onBackPressed();
        }
    }

    class 2 implements View.OnClickListener {
        2() {
        }

        @Override
        public void onClick(View view) {
            if (!TokenActivity.access$0(TokenActivity.this).edittext1.getText().toString().equals("")) {
                TokenActivity.access$1(TokenActivity.this, new HashMap());
                TokenActivity.access$2(TokenActivity.this).put("token", TokenActivity.access$0(TokenActivity.this).edittext1.getText().toString());
                TokenActivity.access$3(TokenActivity.this).setHeaders(TokenActivity.access$4(TokenActivity.this));
                TokenActivity.access$3(TokenActivity.this).setParams(TokenActivity.access$2(TokenActivity.this), 0);
                TokenActivity.access$3(TokenActivity.this).startRequestNetwork("POST", "https://dev-sors.pantheonsite.io/api/validate_token.php", "Check", TokenActivity.access$5(TokenActivity.this));
                return;
            }
            TokenActivity.access$0(TokenActivity.this).textview1.setTextColor(-1499549);
            TokenActivity.access$0(TokenActivity.this).textview1.setText("يوجد فراغ ؟");
        }
    }

    class 3 implements RequestNetwork.RequestListener {
        3() {
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            TokenActivity.access$6(TokenActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            if (TokenActivity.access$4(TokenActivity.this).containsValue("success")) {
                TokenActivity.access$0(TokenActivity.this).textview1.setText(TokenActivity.access$4(TokenActivity.this).get("message").toString());
                TokenActivity.access$7(TokenActivity.this).edit().putString("bot_token", TokenActivity.access$4(TokenActivity.this).get("token").toString()).commit();
                TokenActivity.access$8(TokenActivity.this).setClass(TokenActivity.this.getApplicationContext(), MenuActivity.class);
                TokenActivity.this.startActivity(TokenActivity.access$8(TokenActivity.this));
                return;
            }
            TokenActivity.access$0(TokenActivity.this).textview1.setText(TokenActivity.access$4(TokenActivity.this).get("message").toString());
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    private void initializeLogic() {
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
