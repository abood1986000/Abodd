package com.host.sors;

import android.content.Context;
import android.content.Intent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SketchLogger {
    private static volatile boolean isRunning = false;
    private static Thread loggerThread = new 1();

    class 1 extends Thread {
        1() {
        }

        @Override
        public void run() {
            SketchLogger.access$0(true);
            try {
                Runtime.getRuntime().exec("logcat -c");
                Throwable th = null;
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("logcat").getInputStream()));
                    try {
                        String line = bufferedReader.readLine();
                        do {
                            SketchLogger.broadcastLog(line);
                            if (!SketchLogger.access$1()) {
                                break;
                            } else {
                                line = bufferedReader.readLine();
                            }
                        } while (line != null);
                        if (SketchLogger.access$1()) {
                            SketchLogger.broadcastLog("Logger got killed. Restarting.");
                            SketchLogger.startLogging();
                        } else {
                            SketchLogger.broadcastLog("Logger stopped.");
                        }
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (Throwable th2) {
                        if (bufferedReader == null) {
                            throw th2;
                        }
                        bufferedReader.close();
                        throw th2;
                    }
                } catch (Throwable th3) {
                    if (0 == 0) {
                        throw th3;
                    }
                    if (null != th3) {
                        th.addSuppressed(th3);
                    }
                }
            } catch (IOException e) {
                SketchLogger.broadcastLog(e.getMessage());
            }
        }
    }

    static void access$0(boolean z) {
        isRunning = z;
    }

    static boolean access$1() {
        return isRunning;
    }

    public static synchronized void startLogging() {
        if (!isRunning) {
            loggerThread.start();
        } else {
            broadcastLog("Logger already running");
        }
    }

    public static synchronized void stopLogging() {
        if (isRunning) {
            isRunning = false;
            broadcastLog("Stopping logger by user request.");
        } else {
            broadcastLog("Logger not running");
        }
    }

    public static void broadcastLog(String str) {
        Context context = SketchApplication.getContext();
        Intent intent = new Intent();
        intent.setAction("pro.sketchware.ACTION_NEW_DEBUG_LOG");
        intent.putExtra("log", str);
        intent.putExtra("packageName", context.getPackageName());
        context.sendBroadcast(intent);
    }
}
