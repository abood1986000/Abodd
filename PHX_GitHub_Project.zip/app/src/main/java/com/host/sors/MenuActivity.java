package com.host.sors;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.host.sors.RequestNetwork;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONObject;

public class MenuActivity extends AppCompatActivity {
    private RequestNetwork Get2Req;
    private RequestNetwork GetReq;
    private RequestNetwork WebHook;
    private RequestNetwork.RequestListener _Get2Req_request_listener;
    private RequestNetwork.RequestListener _GetReq_request_listener;
    private RequestNetwork.RequestListener _WebHook_request_listener;
    private RequestNetwork.RequestListener _deleteFileReq_request_listener;
    private RequestNetwork.RequestListener _req_post_file_request_listener;
    private RequestNetwork.RequestListener _req_post_list_file_request_listener;
    private MenuBinding binding;
    private SharedPreferences data;
    private RequestNetwork deleteFileReq;
    private AlertDialog.Builder hh;
    private RequestNetwork req_post_file;
    private RequestNetwork req_post_list_file;
    private AlertDialog.Builder title;
    private AlertDialog.Builder titleon;
    private AlertDialog.Builder tt;
    public final int REQ_CD_SELECT_PHP_FILE = 101;
    private HashMap map_list_file = new HashMap();
    private String filePath = "";
    private String fileName = "";
    private String FileCode = "";
    private HashMap mep_post_file = new HashMap();
    private String codeEncrypted = "";
    private HashMap mep_list_users = new HashMap();
    private HashMap map = new HashMap();
    private String temp = "";
    private HashMap json = new HashMap();
    private HashMap bots = new HashMap();
    private HashMap item = new HashMap();
    private HashMap getMap = new HashMap();
    private ArrayList botList = new ArrayList();
    private ArrayList tmpList = new ArrayList();
    private ArrayList map_list = new ArrayList();
    private ArrayList list = new ArrayList();
    private Intent i = new Intent();
    private Intent Select_php_file = new Intent("android.intent.action.GET_CONTENT");
    private Intent t = new Intent();

    static MenuBinding access$12(MenuActivity menuActivity) {
        return menuActivity.binding;
    }

    static void access$1(MenuActivity menuActivity, HashMap map) {
        menuActivity.map_list_file = map;
    }

    static HashMap access$2(MenuActivity menuActivity) {
        return menuActivity.map_list_file;
    }

    static void access$13(MenuActivity menuActivity, HashMap map) {
        menuActivity.mep_post_file = map;
    }

    static HashMap access$14(MenuActivity menuActivity) {
        return menuActivity.mep_post_file;
    }

    static void access$8(MenuActivity menuActivity, HashMap map) {
        menuActivity.getMap = map;
    }

    static HashMap access$9(MenuActivity menuActivity) {
        return menuActivity.getMap;
    }

    static SharedPreferences access$3(MenuActivity menuActivity) {
        return menuActivity.data;
    }

    static RequestNetwork access$6(MenuActivity menuActivity) {
        return menuActivity.req_post_list_file;
    }

    static RequestNetwork.RequestListener access$7(MenuActivity menuActivity) {
        return menuActivity._req_post_list_file_request_listener;
    }

    static RequestNetwork access$15(MenuActivity menuActivity) {
        return menuActivity.req_post_file;
    }

    static RequestNetwork.RequestListener access$16(MenuActivity menuActivity) {
        return menuActivity._req_post_file_request_listener;
    }

    static RequestNetwork access$10(MenuActivity menuActivity) {
        return menuActivity.GetReq;
    }

    static RequestNetwork.RequestListener access$11(MenuActivity menuActivity) {
        return menuActivity._GetReq_request_listener;
    }

    static RequestNetwork access$4(MenuActivity menuActivity) {
        return menuActivity.deleteFileReq;
    }

    static RequestNetwork.RequestListener access$5(MenuActivity menuActivity) {
        return menuActivity._deleteFileReq_request_listener;
    }

    static AlertDialog.Builder access$0(MenuActivity menuActivity) {
        return menuActivity.tt;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = MenuBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == -1) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1000);
        } else {
            initializeLogic();
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1000) {
            initializeLogic();
        }
    }

    private void initialize(Bundle bundle) {
        setSupportActionBar(this.binding.Toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this.binding.Toolbar.setNavigationOnClickListener(new 1());
        this.data = getSharedPreferences("data", 0);
        this.req_post_list_file = new RequestNetwork(this);
        this.Select_php_file.setType("*/*");
        this.Select_php_file.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
        this.req_post_file = new RequestNetwork(this);
        this.title = new AlertDialog.Builder(this);
        this.titleon = new AlertDialog.Builder(this);
        this.GetReq = new RequestNetwork(this);
        this.deleteFileReq = new RequestNetwork(this);
        this.tt = new AlertDialog.Builder(this);
        this.hh = new AlertDialog.Builder(this);
        this.Get2Req = new RequestNetwork(this);
        this.WebHook = new RequestNetwork(this);
        this.binding.listview1.setOnScrollListener(new 2());
        this.binding.listview1.setOnItemClickListener(new 3());
        this.binding.listview1.setOnItemLongClickListener(new 4());
        this.binding.linear3.setOnClickListener(new 5());
        this.binding.user.setOnClickListener(new 6());
        this.binding.imageview1.setOnClickListener(new 7());
        this._req_post_list_file_request_listener = new 8();
        this._req_post_file_request_listener = new 9();
        this._GetReq_request_listener = new 10();
        this._deleteFileReq_request_listener = new 11();
        this._Get2Req_request_listener = new 12();
        this._WebHook_request_listener = new 13();
    }

    class 1 implements View.OnClickListener {
        1() {
        }

        @Override
        public void onClick(View view) {
            MenuActivity.this.onBackPressed();
        }
    }

    class 2 implements AbsListView.OnScrollListener {
        2() {
        }

        @Override
        public void onScrollStateChanged(AbsListView absListView, int i) {
        }

        @Override
        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }
    }

    class 3 implements AdapterView.OnItemClickListener {
        3() {
        }

        @Override
        public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        }
    }

    class 4 implements AdapterView.OnItemLongClickListener {
        4() {
        }

        @Override
        public boolean onItemLongClick(AdapterView adapterView, View view, int i, long j) {
            return true;
        }
    }

    class 5 implements View.OnClickListener {
        5() {
        }

        @Override
        public void onClick(View view) {
        }
    }

    class 6 implements View.OnClickListener {
        6() {
        }

        @Override
        public void onClick(View view) {
        }
    }

    class 7 implements View.OnClickListener {
        7() {
        }

        @Override
        public void onClick(View view) {
            MenuActivity.access$8(MenuActivity.this, new HashMap());
            MenuActivity.access$9(MenuActivity.this).put("username", MenuActivity.access$3(MenuActivity.this).getString("username", ""));
            MenuActivity.access$9(MenuActivity.this).put("token", MenuActivity.access$3(MenuActivity.this).getString("token", ""));
            MenuActivity.access$10(MenuActivity.this).setParams(MenuActivity.access$9(MenuActivity.this), 0);
            MenuActivity.access$10(MenuActivity.this).startRequestNetwork("GET", "https://sors.alwaysdata.net/user_info", "", MenuActivity.access$11(MenuActivity.this));
        }
    }

    class 8 implements RequestNetwork.RequestListener {
        8() {
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            String strOptString;
            try {
                JSONObject jSONObject = new JSONObject(str2);
                if (jSONObject.getString("status").equals("success")) {
                    JSONArray jSONArray = jSONObject.getJSONArray("files");
                    ArrayList arrayList = new ArrayList();
                    for (int i = 0; i < jSONArray.length(); i++) {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                        HashMap map2 = new HashMap();
                        map2.put("filename", jSONObject2.optString("filename", ""));
                        map2.put("size", jSONObject2.optString("size", "0"));
                        map2.put("code", jSONObject2.optString("code", ""));
                        if (jSONObject2.optString("code", "").length() > 50) {
                            strOptString = jSONObject2.optString("code", "").substring(0, 50);
                        } else {
                            strOptString = jSONObject2.optString("code", "");
                        }
                        map2.put("preview", strOptString);
                        arrayList.add(map2);
                    }
                    MenuActivity.access$12(MenuActivity.this).listview1.setAdapter((ListAdapter) MenuActivity.this.new Listview1Adapter(arrayList));
                } else {
                    return;
                }
            } catch (Exception e) {
                SketchwareUtil.showMessage(MenuActivity.this.getApplicationContext(), e.toString());
            }
            MenuActivity.access$8(MenuActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            SketchwareUtil.showMessage(MenuActivity.this.getApplicationContext(), MenuActivity.access$9(MenuActivity.this).get("status").toString());
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 9 implements RequestNetwork.RequestListener {
        9() {
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            MenuActivity.access$8(MenuActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            if (MenuActivity.access$9(MenuActivity.this).get("status").toString().equals("success")) {
                MenuActivity.access$6(MenuActivity.this).startRequestNetwork("GET", "https://sors.alwaysdata.net/files", "", MenuActivity.access$7(MenuActivity.this));
                SketchwareUtil.showMessage(MenuActivity.this.getApplicationContext(), MenuActivity.access$9(MenuActivity.this).get("status").toString());
            } else {
                SketchwareUtil.showMessage(MenuActivity.this.getApplicationContext(), MenuActivity.access$9(MenuActivity.this).get("status").toString());
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 10 implements RequestNetwork.RequestListener {
        10() {
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            try {
                JSONObject jSONObject = new JSONObject(str2);
                String string = jSONObject.getString("username");
                String string2 = jSONObject.getString("subscription");
                String string3 = jSONObject.getString("expire_date");
                int i = jSONObject.getInt("days_left");
                int i2 = jSONObject.getInt("files_count");
                double d = jSONObject.getDouble("space_mb");
                MenuActivity.access$3(MenuActivity.this).edit().putString("Type", string2).commit();
                JSONArray jSONArray = jSONObject.getJSONArray("instructions");
                StringBuilder sb = new StringBuilder();
                for (int i3 = 0; i3 < jSONArray.length(); i3++) {
                    sb.append("• ").append(jSONArray.getString(i3)).append("\n");
                }
                new AlertDialog.Builder(MenuActivity.this).setTitle("Account Information").setMessage("Username: " + string + "\nSubscription: " + string2 + "\nExpire Date: " + string3 + "\nDays Left: " + i + "\nFiles Count: " + i2 + "\nStorage Used: " + d + " MB\n\nInstructions:\n" + sb.toString()).setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
            } catch (Exception e) {
                Toast.makeText(MenuActivity.this.getApplicationContext(), "Failed to load data", 0).show();
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 11 implements RequestNetwork.RequestListener {
        11() {
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            MenuActivity.access$8(MenuActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            SketchwareUtil.showMessage(MenuActivity.this.getApplicationContext(), MenuActivity.access$9(MenuActivity.this).get("status").toString());
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 12 implements RequestNetwork.RequestListener {
        12() {
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 13 implements RequestNetwork.RequestListener {
        13() {
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            SketchwareUtil.showMessage(MenuActivity.this.getApplicationContext(), str2);
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    private void initializeLogic() {
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swiperefreshlayout1);
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-11751600, -14575885, -26624});
        swipeRefreshLayoutFindViewById.setOnRefreshListener(new 14(swipeRefreshLayoutFindViewById));
        if (!this.data.getString("token", "").equals("")) {
            this.map_list_file = new HashMap();
            this.map_list_file.put("username", this.data.getString("username", ""));
            this.map_list_file.put("token", this.data.getString("token", ""));
            this.req_post_list_file.setParams(this.map_list_file, 0);
            this.req_post_list_file.startRequestNetwork("GET", "https://sors.alwaysdata.net/files", "get file", this._req_post_list_file_request_listener);
            this.binding.user.setText(this.data.getString("username", ""));
            this.getMap = new HashMap();
            this.getMap.put("username", this.data.getString("username", ""));
            this.getMap.put("token", this.data.getString("token", ""));
            this.Get2Req.setParams(this.getMap, 0);
            this.Get2Req.startRequestNetwork("GET", "https://sors.alwaysdata.net/user_info", "get info", this._Get2Req_request_listener);
        } else {
            SketchwareUtil.showMessage(getApplicationContext(), "No user data ");
        }
        FrameLayout frameLayout = (FrameLayout) findViewById(16908290);
        frameLayout.setClipChildren(false);
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(17301547);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(170, 170);
        layoutParams.gravity = 8388693;
        layoutParams.rightMargin = 45;
        layoutParams.bottomMargin = 45;
        imageView.setLayoutParams(layoutParams);
        imageView.setPadding(35, 35, 35, 35);
        imageView.setBackgroundColor(-12627531);
        frameLayout.addView(imageView);
        ImageView imageView2 = new ImageView(this);
        imageView2.setImageResource(17301555);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(145, 145);
        layoutParams2.gravity = 8388693;
        layoutParams2.rightMargin = 70;
        layoutParams2.bottomMargin = 220;
        imageView2.setLayoutParams(layoutParams2);
        imageView2.setPadding(30, 30, 30, 30);
        imageView2.setBackgroundColor(1442840575);
        imageView2.setVisibility(8);
        frameLayout.addView(imageView2);
        ImageView imageView3 = new ImageView(this);
        imageView3.setImageResource(17301589);
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(145, 145);
        layoutParams3.gravity = 8388693;
        layoutParams3.rightMargin = 220;
        layoutParams3.bottomMargin = 120;
        imageView3.setLayoutParams(layoutParams3);
        imageView3.setPadding(30, 30, 30, 30);
        imageView3.setBackgroundColor(1442840575);
        imageView3.setVisibility(8);
        frameLayout.addView(imageView3);
        boolean[] zArr = new boolean[1];
        FrameLayout frameLayout2 = new FrameLayout(this);
        frameLayout2.setBackgroundColor(-587202560);
        frameLayout2.setVisibility(8);
        frameLayout2.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(frameLayout2);
        frameLayout2.bringToFront();
        frameLayout2.setElevation(9999.0f);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(35, 35, 35, 35);
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        frameLayout2.addView(linearLayout);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout.addView(linearLayout2);
        EditText editText = new EditText(this);
        editText.setHint("file.php");
        editText.setTextColor(-1);
        editText.setHintTextColor(-4473925);
        editText.setBackgroundColor(587202559);
        editText.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(editText);
        TextView textView = new TextView(this);
        textView.setText("✕");
        textView.setTextSize(22.0f);
        textView.setPadding(35, 20, 35, 20);
        textView.setTextColor(-1);
        linearLayout2.addView(textView);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        linearLayout.addView(scrollView);
        EditText editText2 = new EditText(this);
        editText2.setHint("PHP Code...");
        editText2.setTextColor(-1);
        editText2.setHintTextColor(-7829368);
        editText2.setGravity(48);
        editText2.setMinLines(24);
        editText2.setTextIsSelectable(true);
        editText2.setBackgroundColor(570425344);
        scrollView.addView(editText2);
        Button button = new Button(this);
        button.setText("UPLOAD FILE");
        button.setTextColor(-1);
        button.setBackgroundColor(-11751600);
        linearLayout.addView(button);
        15 r3 = new 15(imageView2, imageView3, imageView, zArr);
        16 r22 = new 16(frameLayout2);
        imageView.setOnClickListener(new 17(zArr, imageView2, imageView3, imageView, r3));
        imageView2.setOnClickListener(new 18(r3, editText, editText2, frameLayout2));
        imageView3.setOnClickListener(new 19(r3));
        button.setOnClickListener(new 20(editText, editText2, this, r22));
        textView.setOnClickListener(new 21(r22));
        imageView.setOnTouchListener(new 22());
        frameLayout.setFocusableInTouchMode(true);
        frameLayout.requestFocus();
        frameLayout.setOnKeyListener(new 23(frameLayout2, r22, zArr, r3));
        editText2.addTextChangedListener(new 24(editText2));
        FrameLayout frameLayout3 = (FrameLayout) findViewById(16908290);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        frameLayout3.addView(linearLayout3, new FrameLayout.LayoutParams(-1, -1));
        View view = new View(this);
        view.setBackgroundColor(-2013265920);
        view.setAlpha(0.0f);
        view.setVisibility(8);
        linearLayout3.addView(view, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout4 = new LinearLayout(this);
        linearLayout4.setOrientation(0);
        linearLayout4.setGravity(16);
        linearLayout4.setBackgroundColor(-1);
        linearLayout4.setPadding(20, 20, 20, 20);
        linearLayout3.addView(linearLayout4, new LinearLayout.LayoutParams(-1, 150));
        ImageView imageView4 = new ImageView(this);
        imageView4.setImageResource(17301661);
        imageView4.setBackgroundColor(1715425717);
        imageView4.setElevation(12.0f);
        linearLayout4.addView(imageView4, new LinearLayout.LayoutParams(140, 140));
        LinearLayout linearLayout5 = new LinearLayout(this);
        linearLayout5.setOrientation(1);
        linearLayout5.setPadding(25, 25, 25, 25);
        linearLayout5.setBackgroundColor(-15658735);
        FrameLayout.LayoutParams layoutParams4 = new FrameLayout.LayoutParams(850, -1);
        layoutParams4.gravity = 8388611;
        frameLayout3.addView(linearLayout5, layoutParams4);
        linearLayout5.setTranslationX(-900.0f);
        LinearLayout linearLayout6 = new LinearLayout(this);
        linearLayout6.setOrientation(0);
        linearLayout6.setPadding(10, 10, 10, 25);
        linearLayout5.addView(linearLayout6);
        ImageView imageView5 = new ImageView(this);
        imageView5.setImageResource(17301651);
        linearLayout6.addView(imageView5, new LinearLayout.LayoutParams(140, 140));
        LinearLayout linearLayout7 = new LinearLayout(this);
        linearLayout7.setOrientation(1);
        linearLayout7.setPadding(20, 0, 0, 0);
        linearLayout6.addView(linearLayout7);
        TextView textView2 = new TextView(this);
        textView2.setText(this.data.getString("username", "Guest"));
        textView2.setTextColor(-1);
        textView2.setTextSize(20.0f);
        linearLayout7.addView(textView2);
        TextView textView3 = new TextView(this);
        if (this.data.getString("Type", "").equals("premium")) {
            textView3.setText("★ PRIME ACCOUNT");
            textView3.setTextColor(-10929);
        } else {
            textView3.setText("FREE ACCOUNT");
            textView3.setTextColor(-8271996);
        }
        linearLayout7.addView(textView3);
        View view2 = new View(this);
        view2.setBackgroundColor(872415231);
        linearLayout5.addView(view2, new LinearLayout.LayoutParams(-1, 2));
        String[] strArr = {"Upload File", "Create File", "How To Use", "Join", "Developer Youtube", "Share App Link", "Report Problem", "Check Update", "Close Menu"};
        int[] iArr = {17301589, 17301555, 17301568, 17301618, 17301618, 17301586, 17301543, 17301599, 17301560};
        for (int i = 0; i < strArr.length; i++) {
            LinearLayout linearLayout8 = new LinearLayout(this);
            linearLayout8.setOrientation(0);
            linearLayout8.setPadding(25, 25, 25, 25);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-14935012);
            gradientDrawable.setCornerRadius(25.0f);
            gradientDrawable.setStroke(2, 587202559);
            linearLayout8.setBackground(gradientDrawable);
            ImageView imageView6 = new ImageView(this);
            imageView6.setImageResource(iArr[i]);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(80, 80);
            layoutParams5.rightMargin = 25;
            linearLayout8.addView(imageView6, layoutParams5);
            TextView textView4 = new TextView(this);
            textView4.setText(strArr[i]);
            textView4.setTextColor(-1);
            textView4.setTextSize(17.0f);
            linearLayout8.addView(textView4);
            linearLayout8.setOnClickListener(new 25(i, linearLayout5, view));
            linearLayout5.addView(linearLayout8);
        }
        TextView textView5 = new TextView(this);
        textView5.setText("Version 1.0.0");
        textView5.setTextColor(1442840575);
        linearLayout5.addView(textView5);
        TextView textView6 = new TextView(this);
        textView6.setText("Verified Developer ✓ GHAZAWI");
        textView6.setTextColor(-1426074289);
        linearLayout5.addView(textView6);
        imageView4.setOnClickListener(new 26(view, linearLayout5));
        view.setOnClickListener(new 27(linearLayout5, view));
    }

    class 14 implements SwipeRefreshLayout.OnRefreshListener {
        private final SwipeRefreshLayout val$refresh;

        14(SwipeRefreshLayout swipeRefreshLayout) {
            this.val$refresh = swipeRefreshLayout;
        }

        static MenuActivity access$0(14 r1) {
            return MenuActivity.this;
        }

        public void onRefresh() {
            this.val$refresh.setRefreshing(true);
            new Handler().postDelayed(new 1(this.val$refresh), 2000L);
        }

        class 1 implements Runnable {
            private final SwipeRefreshLayout val$refresh;

            1(SwipeRefreshLayout swipeRefreshLayout) {
                this.val$refresh = swipeRefreshLayout;
            }

            @Override
            public void run() {
                this.val$refresh.setRefreshing(false);
                MenuActivity.access$6(14.access$0(14.this)).startRequestNetwork("GET", "https://sors.alwaysdata.net/files", "get file", MenuActivity.access$7(14.access$0(14.this)));
                MenuActivity.access$6(14.access$0(14.this)).setParams(MenuActivity.access$2(14.access$0(14.this)), 0);
            }
        }
    }

    class 15 implements Runnable {
        private final ImageView val$createBtn;
        private final ImageView val$fab;
        private final boolean[] val$fabOpen;
        private final ImageView val$uploadBtn;

        15(ImageView imageView, ImageView imageView2, ImageView imageView3, boolean[] zArr) {
            this.val$createBtn = imageView;
            this.val$uploadBtn = imageView2;
            this.val$fab = imageView3;
            this.val$fabOpen = zArr;
        }

        @Override
        public void run() {
            this.val$createBtn.setVisibility(8);
            this.val$uploadBtn.setVisibility(8);
            this.val$fab.setRotation(0.0f);
            this.val$fabOpen[0] = false;
        }
    }

    class 16 implements Runnable {
        private final FrameLayout val$editorLayer;

        16(FrameLayout frameLayout) {
            this.val$editorLayer = frameLayout;
        }

        @Override
        public void run() {
            this.val$editorLayer.setVisibility(8);
        }
    }

    class 17 implements View.OnClickListener {
        private final Runnable val$closeFab;
        private final ImageView val$createBtn;
        private final ImageView val$fab;
        private final boolean[] val$fabOpen;
        private final ImageView val$uploadBtn;

        17(boolean[] zArr, ImageView imageView, ImageView imageView2, ImageView imageView3, Runnable runnable) {
            this.val$fabOpen = zArr;
            this.val$createBtn = imageView;
            this.val$uploadBtn = imageView2;
            this.val$fab = imageView3;
            this.val$closeFab = runnable;
        }

        @Override
        public void onClick(View view) {
            if (!this.val$fabOpen[0]) {
                this.val$createBtn.setVisibility(0);
                this.val$uploadBtn.setVisibility(0);
                this.val$createBtn.setAlpha(0.0f);
                this.val$uploadBtn.setAlpha(0.0f);
                this.val$createBtn.animate().alpha(1.0f).setDuration(180L);
                this.val$uploadBtn.animate().alpha(1.0f).setDuration(180L);
                this.val$fab.animate().rotation(45.0f).setDuration(180L);
                this.val$fabOpen[0] = true;
                return;
            }
            this.val$closeFab.run();
        }
    }

    class 18 implements View.OnClickListener {
        private final Runnable val$closeFab;
        private final EditText val$editor;
        private final FrameLayout val$editorLayer;
        private final EditText val$fileName;

        18(Runnable runnable, EditText editText, EditText editText2, FrameLayout frameLayout) {
            this.val$closeFab = runnable;
            this.val$fileName = editText;
            this.val$editor = editText2;
            this.val$editorLayer = frameLayout;
        }

        @Override
        public void onClick(View view) {
            this.val$closeFab.run();
            this.val$fileName.setText("");
            this.val$editor.setText("<?php\n\n?>");
            this.val$editorLayer.setVisibility(0);
            this.val$editorLayer.bringToFront();
        }
    }

    class 19 implements View.OnClickListener {
        private final Runnable val$closeFab;

        19(Runnable runnable) {
            this.val$closeFab = runnable;
        }

        @Override
        public void onClick(View view) {
            this.val$closeFab.run();
            Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
            intent.setType("*/*");
            intent.addCategory("android.intent.category.OPENABLE");
            MenuActivity.this.startActivityForResult(Intent.createChooser(intent, "Select File"), 101);
        }
    }

    class 20 implements View.OnClickListener {
        private final Runnable val$closeEditor;
        private final Context val$ctx;
        private final EditText val$editor;
        private final EditText val$fileName;

        20(EditText editText, EditText editText2, Context context, Runnable runnable) {
            this.val$fileName = editText;
            this.val$editor = editText2;
            this.val$ctx = context;
            this.val$closeEditor = runnable;
        }

        @Override
        public void onClick(View view) {
            String strTrim = this.val$fileName.getText().toString().trim();
            String string = this.val$editor.getText().toString();
            if (strTrim.equals("")) {
                SketchwareUtil.showMessage(this.val$ctx, "Enter file name");
                return;
            }
            if (string.equals("")) {
                SketchwareUtil.showMessage(this.val$ctx, "Code is empty");
                return;
            }
            if (!strTrim.endsWith(".php")) {
                strTrim = String.valueOf(strTrim) + ".php";
            }
            MenuActivity.access$13(MenuActivity.this, new HashMap());
            MenuActivity.access$14(MenuActivity.this).put("username", MenuActivity.access$3(MenuActivity.this).getString("username", ""));
            MenuActivity.access$14(MenuActivity.this).put("code", string);
            MenuActivity.access$14(MenuActivity.this).put("botname", strTrim);
            MenuActivity.access$14(MenuActivity.this).put("token", MenuActivity.access$3(MenuActivity.this).getString("token", ""));
            MenuActivity.access$14(MenuActivity.this).put("bot_token", "Dev-GHAZAWI-VIP");
            MenuActivity.access$15(MenuActivity.this).setParams(MenuActivity.access$14(MenuActivity.this), 0);
            MenuActivity.access$15(MenuActivity.this).startRequestNetwork("POST", "https://sors.alwaysdata.net/upload", "", MenuActivity.access$16(MenuActivity.this));
            SketchwareUtil.showMessage(this.val$ctx, "Uploading...");
            this.val$closeEditor.run();
        }
    }

    class 21 implements View.OnClickListener {
        private final Runnable val$closeEditor;

        21(Runnable runnable) {
            this.val$closeEditor = runnable;
        }

        @Override
        public void onClick(View view) {
            this.val$closeEditor.run();
        }
    }

    class 22 implements View.OnTouchListener {
        float downX;
        float downY;
        float dx;
        float dy;
        boolean moved = false;

        22() {
        }

        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case 0:
                    this.dx = view.getX() - motionEvent.getRawX();
                    this.dy = view.getY() - motionEvent.getRawY();
                    this.downX = motionEvent.getRawX();
                    this.downY = motionEvent.getRawY();
                    this.moved = false;
                    return false;
                case 1:
                default:
                    return false;
                case 2:
                    float rawX = motionEvent.getRawX() + this.dx;
                    float rawY = motionEvent.getRawY() + this.dy;
                    view.setX(rawX);
                    view.setY(rawY);
                    if (Math.abs(motionEvent.getRawX() - this.downX) > 10.0f || Math.abs(motionEvent.getRawY() - this.downY) > 10.0f) {
                        this.moved = true;
                    }
                    return true;
            }
        }
    }

    class 23 implements View.OnKeyListener {
        private final Runnable val$closeEditor;
        private final Runnable val$closeFab;
        private final FrameLayout val$editorLayer;
        private final boolean[] val$fabOpen;

        23(FrameLayout frameLayout, Runnable runnable, boolean[] zArr, Runnable runnable2) {
            this.val$editorLayer = frameLayout;
            this.val$closeEditor = runnable;
            this.val$fabOpen = zArr;
            this.val$closeFab = runnable2;
        }

        @Override
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (i == 4 && keyEvent.getAction() == 1) {
                if (this.val$editorLayer.getVisibility() == 0) {
                    this.val$closeEditor.run();
                    return true;
                }
                if (this.val$fabOpen[0]) {
                    this.val$closeFab.run();
                    return true;
                }
            }
            return false;
        }
    }

    class 24 implements TextWatcher {
        private final EditText val$editor;

        24(EditText editText) {
            this.val$editor = editText;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
            this.val$editor.removeTextChangedListener(this);
            String string = editable.toString();
            SpannableString spannableString = new SpannableString(string);
            for (String str : new String[]{"<?php", "echo", "if", "else", "for", "while", "function", "return", "class", "new"}) {
                for (int iIndexOf = string.indexOf(str); iIndexOf >= 0; iIndexOf = string.indexOf(str, iIndexOf + 1)) {
                    spannableString.setSpan(new ForegroundColorSpan(-11751600), iIndexOf, str.length() + iIndexOf, 0);
                }
            }
            this.val$editor.setText(spannableString);
            this.val$editor.setSelection(spannableString.length());
            this.val$editor.addTextChangedListener(this);
        }
    }

    class 25 implements View.OnClickListener {
        private final View val$overlayBg;
        private final int val$pos;
        private final LinearLayout val$sideMenu;

        25(int i, LinearLayout linearLayout, View view) {
            this.val$pos = i;
            this.val$sideMenu = linearLayout;
            this.val$overlayBg = view;
        }

        @Override
        public void onClick(View view) {
            if (this.val$pos == 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
                builder.setTitle("Upload File");
                builder.setMessage("Open file manager to select file.");
                builder.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
                builder.show();
            } else if (this.val$pos == 1) {
                AlertDialog.Builder builder2 = new AlertDialog.Builder(MenuActivity.this);
                builder2.setTitle("Create File");
                builder2.setMessage("Open editor to create file.");
                builder2.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
                builder2.show();
            } else if (this.val$pos == 2) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse("https://t.me/cddok"));
                MenuActivity.this.startActivity(intent);
            } else if (this.val$pos == 3) {
                Intent intent2 = new Intent("android.intent.action.VIEW");
                intent2.setData(Uri.parse("https://t.me/sorsapi"));
                MenuActivity.this.startActivity(intent2);
            } else if (this.val$pos == 4) {
                Intent intent3 = new Intent("android.intent.action.VIEW");
                intent3.setData(Uri.parse("https://t.me/Ad11Vantage"));
                MenuActivity.this.startActivity(intent3);
            } else if (this.val$pos == 5) {
                Intent intent4 = new Intent("android.intent.action.SEND");
                intent4.setType("text/plain");
                intent4.putExtra("android.intent.extra.TEXT", "https://t.me/sorsapi");
                MenuActivity.this.startActivity(Intent.createChooser(intent4, "Share App Link"));
            } else if (this.val$pos == 6) {
                Intent intent5 = new Intent("android.intent.action.VIEW");
                intent5.setData(Uri.parse("https://t.me/chatkyodo"));
                MenuActivity.this.startActivity(intent5);
            } else if (this.val$pos == 7) {
                AlertDialog.Builder builder3 = new AlertDialog.Builder(MenuActivity.this);
                builder3.setTitle("Update");
                builder3.setMessage("You are using latest version.");
                builder3.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
                builder3.show();
            } else if (this.val$pos == 8) {
                this.val$sideMenu.animate().translationX(-900.0f).setDuration(250L);
                this.val$overlayBg.animate().alpha(0.0f).setDuration(200L);
                this.val$overlayBg.setVisibility(8);
                return;
            }
            this.val$sideMenu.animate().translationX(-900.0f).setDuration(250L);
            this.val$overlayBg.animate().alpha(0.0f).setDuration(200L);
            this.val$overlayBg.setVisibility(8);
        }
    }

    class 26 implements View.OnClickListener {
        private final View val$overlayBg;
        private final LinearLayout val$sideMenu;

        26(View view, LinearLayout linearLayout) {
            this.val$overlayBg = view;
            this.val$sideMenu = linearLayout;
        }

        @Override
        public void onClick(View view) {
            this.val$overlayBg.setVisibility(0);
            this.val$overlayBg.animate().alpha(1.0f).setDuration(200L);
            this.val$sideMenu.animate().translationX(0.0f).setDuration(250L);
        }
    }

    class 27 implements View.OnClickListener {
        private final View val$overlayBg;
        private final LinearLayout val$sideMenu;

        27(LinearLayout linearLayout, View view) {
            this.val$sideMenu = linearLayout;
            this.val$overlayBg = view;
        }

        @Override
        public void onClick(View view) {
            this.val$sideMenu.animate().translationX(-900.0f).setDuration(250L);
            this.val$overlayBg.animate().alpha(0.0f).setDuration(200L);
            this.val$overlayBg.setVisibility(8);
        }
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        String file;
        String lastPathSegment;
        super.onActivityResult(i, i2, intent);
        switch (i) {
            case 101:
                if (i2 == -1) {
                    ArrayList arrayList = new ArrayList();
                    if (intent != null) {
                        if (intent.getClipData() != null) {
                            for (int i3 = 0; i3 < intent.getClipData().getItemCount(); i3++) {
                                arrayList.add(FileUtil.convertUriToFilePath(getApplicationContext(), intent.getClipData().getItemAt(i3).getUri()));
                            }
                        } else {
                            arrayList.add(FileUtil.convertUriToFilePath(getApplicationContext(), intent.getData()));
                        }
                    }
                    String str = (String) arrayList.get(0);
                    try {
                        if (str.startsWith("content://")) {
                            Uri uri = Uri.parse(str);
                            InputStream inputStreamOpenInputStream = getContentResolver().openInputStream(uri);
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            byte[] bArr = new byte[4096];
                            while (true) {
                                int i4 = inputStreamOpenInputStream.read(bArr, 0, bArr.length);
                                if (i4 != -1) {
                                    byteArrayOutputStream.write(bArr, 0, i4);
                                } else {
                                    byteArrayOutputStream.flush();
                                    String str2 = new String(byteArrayOutputStream.toByteArray(), "UTF-8");
                                    Cursor cursorQuery = getContentResolver().query(uri, null, null, null, null);
                                    if (cursorQuery == null) {
                                        lastPathSegment = "upload.php";
                                    } else {
                                        int columnIndex = cursorQuery.getColumnIndex("_display_name");
                                        if (!cursorQuery.moveToFirst()) {
                                            lastPathSegment = "upload.php";
                                        } else {
                                            lastPathSegment = cursorQuery.getString(columnIndex);
                                        }
                                        cursorQuery.close();
                                    }
                                    inputStreamOpenInputStream.close();
                                    file = str2;
                                }
                            }
                        } else {
                            file = FileUtil.readFile(str);
                            lastPathSegment = Uri.parse(str).getLastPathSegment();
                        }
                        if (!file.trim().equals("")) {
                            this.data.edit().putString("file", lastPathSegment).commit();
                            this.data.edit().putString("code", file).commit();
                            this.title.setTitle("Perform lifts Make an appropriate decision");
                            this.title.setIcon(R.drawable.icon_arrow_circle_up_round);
                            this.title.setMessage("Are you sure to upload this file : ".concat(lastPathSegment));
                            this.mep_post_file = new HashMap();
                            this.mep_post_file.put("username", this.data.getString("username", ""));
                            this.mep_post_file.put("code", file);
                            this.mep_post_file.put("botname", lastPathSegment);
                            this.mep_post_file.put("token", this.data.getString("token", ""));
                            this.mep_post_file.put("bot_token", "Dev-GHAZAWI-VIP");
                            this.req_post_file.setParams(this.mep_post_file, 0);
                            this.req_post_file.startRequestNetwork("POST", "https://sors.alwaysdata.net/upload", "", this._req_post_file_request_listener);
                        } else {
                            SketchwareUtil.showMessage(getApplicationContext(), "The file is empty");
                        }
                    } catch (Exception e) {
                        SketchwareUtil.showMessage(getApplicationContext(), e.toString());
                        return;
                    }
                }
                break;
        }
    }

    public class Listview1Adapter extends BaseAdapter {
        ArrayList _data;

        static MenuActivity access$1(Listview1Adapter listview1Adapter) {
            return MenuActivity.this;
        }

        public Listview1Adapter(ArrayList arrayList) {
            this._data = arrayList;
        }

        @Override
        public int getCount() {
            return this._data.size();
        }

        @Override
        public HashMap getItem(int i) {
            return (HashMap) this._data.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            BotsBinding botsBindingInflate = BotsBinding.inflate(MenuActivity.this.getLayoutInflater());
            LinearLayout root = botsBindingInflate.getRoot();
            botsBindingInflate.textview1.setText(((HashMap) this._data.get(i)).get("filename").toString());
            botsBindingInflate.textview2.setText(String.valueOf(((HashMap) this._data.get(i)).get("size").toString()) + " bytes");
            botsBindingInflate.linear2.setPadding(25, 20, 25, 20);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-1);
            gradientDrawable.setCornerRadius(40.0f);
            gradientDrawable.setStroke(3, -5912923);
            botsBindingInflate.linear2.setBackground(gradientDrawable);
            botsBindingInflate.Delete.setOnClickListener(new 1(i));
            botsBindingInflate.Copy.setOnClickListener(new 2(i));
            botsBindingInflate.WebHook.setOnClickListener(new 3(i));
            botsBindingInflate.editer.setOnClickListener(new 4(i));
            return root;
        }

        class 1 implements View.OnClickListener {
            private final int val$_position;

            1(int i) {
                this.val$_position = i;
            }

            static Listview1Adapter access$0(1 r1) {
                return Listview1Adapter.this;
            }

            class 1 implements DialogInterface.OnClickListener {
                private final int val$_position;

                1(int i) {
                    this.val$_position = i;
                }

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    MenuActivity.access$1(Listview1Adapter.access$1(1.access$0(1.this)), new HashMap());
                    MenuActivity.access$2(Listview1Adapter.access$1(1.access$0(1.this))).put("username", MenuActivity.access$3(Listview1Adapter.access$1(1.access$0(1.this))).getString("username", ""));
                    MenuActivity.access$2(Listview1Adapter.access$1(1.access$0(1.this))).put("token", MenuActivity.access$3(Listview1Adapter.access$1(1.access$0(1.this))).getString("token", ""));
                    MenuActivity.access$2(Listview1Adapter.access$1(1.access$0(1.this))).put("file", ((HashMap) 1.access$0(1.this)._data.get(this.val$_position)).get("filename").toString());
                    MenuActivity.access$4(Listview1Adapter.access$1(1.access$0(1.this))).setParams(MenuActivity.access$2(Listview1Adapter.access$1(1.access$0(1.this))), 0);
                    MenuActivity.access$4(Listview1Adapter.access$1(1.access$0(1.this))).startRequestNetwork("POST", "https://sors.alwaysdata.net/delete_file", "", MenuActivity.access$5(Listview1Adapter.access$1(1.access$0(1.this))));
                    MenuActivity.access$6(Listview1Adapter.access$1(1.access$0(1.this))).startRequestNetwork("GET", "https://sors.alwaysdata.net/files", "", MenuActivity.access$7(Listview1Adapter.access$1(1.access$0(1.this))));
                }
            }

            @Override
            public void onClick(View view) {
                MenuActivity.access$0(Listview1Adapter.access$1(Listview1Adapter.this)).setTitle("Warning: Do you want to delete the file");
                MenuActivity.access$0(Listview1Adapter.access$1(Listview1Adapter.this)).setPositiveButton("yes", new 1(this.val$_position));
                MenuActivity.access$0(Listview1Adapter.access$1(Listview1Adapter.this)).setNegativeButton("no", new 2());
                MenuActivity.access$0(Listview1Adapter.access$1(Listview1Adapter.this)).create().show();
            }

            class 2 implements DialogInterface.OnClickListener {
                2() {
                }

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }
        }

        class 2 implements View.OnClickListener {
            private final int val$_position;

            2(int i) {
                this.val$_position = i;
            }

            @Override
            public void onClick(View view) {
                MenuActivity menuActivityAccess$1 = Listview1Adapter.access$1(Listview1Adapter.this);
                Listview1Adapter.access$1(Listview1Adapter.this).getApplicationContext();
                ((ClipboardManager) menuActivityAccess$1.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("clipboard", "https://sors.alwaysdata.net/".concat("users/".concat(MenuActivity.access$3(Listview1Adapter.access$1(Listview1Adapter.this)).getString("username", "").concat("/bots/".concat(((HashMap) Listview1Adapter.this._data.get(this.val$_position)).get("filename").toString()))))));
                SketchwareUtil.showMessage(Listview1Adapter.access$1(Listview1Adapter.this).getApplicationContext(), "https://sors.alwaysdata.net/".concat("users/".concat(MenuActivity.access$3(Listview1Adapter.access$1(Listview1Adapter.this)).getString("username", "").concat("/bots/".concat(((HashMap) Listview1Adapter.this._data.get(this.val$_position)).get("filename").toString())))));
            }
        }

        class 3 implements View.OnClickListener {
            private final int val$_position;

            3(int i) {
                this.val$_position = i;
            }

            static Listview1Adapter access$0(3 r1) {
                return Listview1Adapter.this;
            }

            @Override
            public void onClick(View view) {
                LinearLayout linearLayout = new LinearLayout(Listview1Adapter.access$1(Listview1Adapter.this));
                linearLayout.setOrientation(1);
                linearLayout.setPadding(60, 60, 60, 60);
                linearLayout.setBackgroundColor(-15658735);
                EditText editText = new EditText(Listview1Adapter.access$1(Listview1Adapter.this));
                editText.setHint("Enter Telegram Token");
                editText.setTextColor(-1);
                editText.setHintTextColor(-7829334);
                editText.setPadding(40, 30, 40, 30);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(570425344);
                gradientDrawable.setCornerRadius(50.0f);
                gradientDrawable.setStroke(2, -8758017);
                editText.setBackground(gradientDrawable);
                TextView textView = new TextView(Listview1Adapter.access$1(Listview1Adapter.this));
                textView.setText("");
                textView.setTextColor(-16718218);
                textView.setTextSize(14.0f);
                textView.setPadding(10, 30, 10, 10);
                textView.setVisibility(8);
                Button button = new Button(Listview1Adapter.access$1(Listview1Adapter.this));
                button.setText("Create WebHook");
                button.setTextColor(-1);
                GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{-8758017, -11899649});
                gradientDrawable2.setCornerRadius(60.0f);
                button.setBackground(gradientDrawable2);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 140);
                layoutParams.setMargins(0, 50, 0, 0);
                button.setLayoutParams(layoutParams);
                linearLayout.addView(editText);
                linearLayout.addView(button);
                linearLayout.addView(textView);
                AlertDialog alertDialogCreate = new AlertDialog.Builder(Listview1Adapter.access$1(Listview1Adapter.this)).setView(linearLayout).create();
                alertDialogCreate.show();
                if (alertDialogCreate.getWindow() != null) {
                    alertDialogCreate.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                }
                button.setOnClickListener(new 1(editText, textView, this.val$_position, new RequestNetwork(Listview1Adapter.access$1(Listview1Adapter.this))));
            }

            class 1 implements View.OnClickListener {
                private final int val$_position;
                private final EditText val$input;
                private final RequestNetwork val$req;
                private final TextView val$result;

                1(EditText editText, TextView textView, int i, RequestNetwork requestNetwork) {
                    this.val$input = editText;
                    this.val$result = textView;
                    this.val$_position = i;
                    this.val$req = requestNetwork;
                }

                class 1 implements Runnable {
                    private final View val$v;

                    1(View view) {
                        this.val$v = view;
                    }

                    @Override
                    public void run() {
                        this.val$v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120L);
                    }
                }

                @Override
                public void onClick(View view) {
                    view.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80L).withEndAction(new 1(view));
                    String strTrim = this.val$input.getText().toString().trim();
                    if (strTrim.equals("")) {
                        this.val$result.setVisibility(0);
                        this.val$result.setTextColor(-44462);
                        this.val$result.setText("Enter token first");
                        return;
                    }
                    String string = ((HashMap) 3.access$0(3.this)._data.get(this.val$_position)).get("filename").toString();
                    HashMap map = new HashMap();
                    map.put("token", strTrim);
                    map.put("file", string);
                    map.put("user", MenuActivity.access$3(Listview1Adapter.access$1(3.access$0(3.this))).getString("username", ""));
                    this.val$req.setParams(map, 0);
                    this.val$req.startRequestNetwork("POST", "https://sors.alwaysdata.net/setWebhook.php", "", new 2(this.val$result));
                }

                class 2 implements RequestNetwork.RequestListener {
                    private final TextView val$result;

                    2(TextView textView) {
                        this.val$result = textView;
                    }

                    @Override
                    public void onResponse(String str, String str2, HashMap map) {
                        try {
                            JSONObject jSONObject = new JSONObject(str2);
                            boolean z = jSONObject.getBoolean("ok");
                            this.val$result.setVisibility(0);
                            if (z) {
                                this.val$result.setTextColor(-16718218);
                                this.val$result.setText("✔ WebHook Created\n" + jSONObject.getString("message"));
                            } else {
                                this.val$result.setTextColor(-44462);
                                this.val$result.setText("Failed:\n" + jSONObject.getString("message"));
                            }
                            this.val$result.setAlpha(0.0f);
                            this.val$result.setTranslationY(40.0f);
                            this.val$result.animate().alpha(1.0f).translationY(0.0f).setDuration(250L);
                        } catch (Exception e) {
                            this.val$result.setVisibility(0);
                            this.val$result.setTextColor(-44462);
                            this.val$result.setText("Parse Error:\n" + str2);
                        }
                    }

                    @Override
                    public void onErrorResponse(String str, String str2) {
                        this.val$result.setVisibility(0);
                        this.val$result.setTextColor(-44462);
                        this.val$result.setText("Server Error:\n" + str2);
                    }
                }
            }
        }

        class 4 implements View.OnClickListener {
            private final int val$_position;

            4(int i) {
                this.val$_position = i;
            }

            static Listview1Adapter access$0(4 r1) {
                return Listview1Adapter.this;
            }

            @Override
            public void onClick(View view) {
                FrameLayout frameLayout = (FrameLayout) Listview1Adapter.access$1(Listview1Adapter.this).findViewById(16908290);
                frameLayout.setClipChildren(false);
                AppCompatActivity appCompatActivityAccess$1 = Listview1Adapter.access$1(Listview1Adapter.this);
                FrameLayout frameLayout2 = new FrameLayout(Listview1Adapter.access$1(Listview1Adapter.this));
                frameLayout2.setBackgroundColor(-587202560);
                frameLayout2.setVisibility(8);
                frameLayout.addView(frameLayout2);
                LinearLayout linearLayout = new LinearLayout(Listview1Adapter.access$1(Listview1Adapter.this));
                linearLayout.setOrientation(1);
                linearLayout.setPadding(35, 35, 35, 35);
                frameLayout2.addView(linearLayout);
                LinearLayout linearLayout2 = new LinearLayout(Listview1Adapter.access$1(Listview1Adapter.this));
                linearLayout2.setOrientation(0);
                linearLayout.addView(linearLayout2);
                EditText editText = new EditText(Listview1Adapter.access$1(Listview1Adapter.this));
                editText.setHint("file.php");
                editText.setTextColor(-1);
                editText.setHintTextColor(-5592406);
                editText.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                linearLayout2.addView(editText);
                TextView textView = new TextView(Listview1Adapter.access$1(Listview1Adapter.this));
                textView.setText("✕");
                textView.setTextColor(-1);
                textView.setTextSize(22.0f);
                textView.setPadding(25, 10, 25, 10);
                linearLayout2.addView(textView);
                ScrollView scrollView = new ScrollView(Listview1Adapter.access$1(Listview1Adapter.this));
                scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
                linearLayout.addView(scrollView);
                EditText editText2 = new EditText(Listview1Adapter.access$1(Listview1Adapter.this));
                editText2.setHint("PHP Code...");
                editText2.setTextColor(-1);
                editText2.setHintTextColor(-8947849);
                editText2.setBackgroundColor(570425344);
                editText2.setGravity(48);
                editText2.setPadding(20, 20, 20, 20);
                scrollView.addView(editText2);
                Button button = new Button(Listview1Adapter.access$1(Listview1Adapter.this));
                button.setText("UPLOAD FILE");
                button.setTextColor(-1);
                button.setBackgroundColor(-11751600);
                linearLayout.addView(button);
                HashMap map = new HashMap();
                Uri[] uriArr = new Uri[1];
                RequestNetwork requestNetwork = new RequestNetwork(Listview1Adapter.access$1(Listview1Adapter.this));
                try {
                    int i = this.val$_position;
                    if (i >= 0 && i < Listview1Adapter.this._data.size()) {
                        String string = ((HashMap) Listview1Adapter.this._data.get(i)).get("filename").toString();
                        String string2 = ((HashMap) Listview1Adapter.this._data.get(i)).get("code").toString();
                        frameLayout2.setVisibility(0);
                        editText.setText(string);
                        editText2.setText(string2);
                    } else {
                        return;
                    }
                } catch (Exception e) {
                    SketchwareUtil.showMessage(appCompatActivityAccess$1, e.toString());
                }
                textView.setOnClickListener(new 1(frameLayout2));
                button.setOnClickListener(new 2(editText, editText2, appCompatActivityAccess$1, map, uriArr, requestNetwork, frameLayout2));
            }

            class 1 implements View.OnClickListener {
                private final FrameLayout val$editorLayer;

                1(FrameLayout frameLayout) {
                    this.val$editorLayer = frameLayout;
                }

                @Override
                public void onClick(View view) {
                    this.val$editorLayer.setVisibility(8);
                }
            }

            class 2 implements View.OnClickListener {
                private final Context val$ctx;
                private final EditText val$editor;
                private final FrameLayout val$editorLayer;
                private final EditText val$fileName;
                private final HashMap val$map;
                private final RequestNetwork val$req;
                private final Uri[] val$selectedFile;

                2(EditText editText, EditText editText2, Context context, HashMap map, Uri[] uriArr, RequestNetwork requestNetwork, FrameLayout frameLayout) {
                    this.val$fileName = editText;
                    this.val$editor = editText2;
                    this.val$ctx = context;
                    this.val$map = map;
                    this.val$selectedFile = uriArr;
                    this.val$req = requestNetwork;
                    this.val$editorLayer = frameLayout;
                }

                @Override
                public void onClick(View view) {
                    String strTrim = this.val$fileName.getText().toString().trim();
                    String string = this.val$editor.getText().toString();
                    if (strTrim.equals("")) {
                        SketchwareUtil.showMessage(this.val$ctx, "Enter file name");
                        return;
                    }
                    if (!strTrim.endsWith(".php")) {
                        strTrim = String.valueOf(strTrim) + ".php";
                    }
                    this.val$map.clear();
                    this.val$map.put("username", MenuActivity.access$3(Listview1Adapter.access$1(4.access$0(4.this))).getString("username", ""));
                    this.val$map.put("token", MenuActivity.access$3(Listview1Adapter.access$1(4.access$0(4.this))).getString("token", ""));
                    this.val$map.put("bot_token", "Dev-GHAZAWI-VIP");
                    this.val$map.put("botname", strTrim);
                    this.val$map.put("code", string);
                    if (this.val$selectedFile[0] != null) {
                        this.val$map.put("file_uri", this.val$selectedFile[0].toString());
                    }
                    this.val$req.setParams(this.val$map, 0);
                    this.val$req.startRequestNetwork("POST", "https://sors.alwaysdata.net/upload", "", new 1(this.val$ctx, this.val$editorLayer));
                }

                class 1 implements RequestNetwork.RequestListener {
                    private final Context val$ctx;
                    private final FrameLayout val$editorLayer;

                    1(Context context, FrameLayout frameLayout) {
                        this.val$ctx = context;
                        this.val$editorLayer = frameLayout;
                    }

                    @Override
                    public void onResponse(String str, String str2, HashMap map) {
                        SketchwareUtil.showMessage(this.val$ctx, "Uploaded OK");
                        this.val$editorLayer.setVisibility(8);
                    }

                    @Override
                    public void onErrorResponse(String str, String str2) {
                        SketchwareUtil.showMessage(this.val$ctx, "Upload Error");
                    }
                }
            }
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
