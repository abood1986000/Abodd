package com.host.sors;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.host.sors.RequestNetwork;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private AlertDialog.Builder Maintenance;
    private TimerTask Show_time;
    private RequestNetwork.RequestListener _events_request_listener;
    private RequestNetwork.RequestListener _req_Create_request_listener;
    private RequestNetwork.RequestListener _req_login_request_listener;
    private MainBinding binding;
    private SharedPreferences data;
    private RequestNetwork events;
    private RequestNetwork req_Create;
    private RequestNetwork req_login;
    private Timer _timer = new Timer();
    private String s_login_status = "";
    private HashMap mepCreate = new HashMap();
    private HashMap map_json_create = new HashMap();
    private HashMap maplogin = new HashMap();
    private HashMap map_json_login = new HashMap();
    private String encodedToken = "";
    private String originalToken = "";
    private String deviceId = "";
    private Intent New_page = new Intent();
    private Intent i = new Intent();

    static Timer access$2(MainActivity mainActivity) {
        return mainActivity._timer;
    }

    static MainBinding access$0(MainActivity mainActivity) {
        return mainActivity.binding;
    }

    static void access$8(MainActivity mainActivity, HashMap map) {
        mainActivity.mepCreate = map;
    }

    static HashMap access$9(MainActivity mainActivity) {
        return mainActivity.mepCreate;
    }

    static void access$13(MainActivity mainActivity, HashMap map) {
        mainActivity.map_json_create = map;
    }

    static HashMap access$14(MainActivity mainActivity) {
        return mainActivity.map_json_create;
    }

    static void access$4(MainActivity mainActivity, HashMap map) {
        mainActivity.maplogin = map;
    }

    static HashMap access$5(MainActivity mainActivity) {
        return mainActivity.maplogin;
    }

    static void access$15(MainActivity mainActivity, HashMap map) {
        mainActivity.map_json_login = map;
    }

    static HashMap access$16(MainActivity mainActivity) {
        return mainActivity.map_json_login;
    }

    static RequestNetwork access$10(MainActivity mainActivity) {
        return mainActivity.req_Create;
    }

    static RequestNetwork.RequestListener access$11(MainActivity mainActivity) {
        return mainActivity._req_Create_request_listener;
    }

    static void access$1(MainActivity mainActivity, TimerTask timerTask) {
        mainActivity.Show_time = timerTask;
    }

    static TimerTask access$3(MainActivity mainActivity) {
        return mainActivity.Show_time;
    }

    static RequestNetwork access$6(MainActivity mainActivity) {
        return mainActivity.req_login;
    }

    static RequestNetwork.RequestListener access$7(MainActivity mainActivity) {
        return mainActivity._req_login_request_listener;
    }

    static Intent access$18(MainActivity mainActivity) {
        return mainActivity.New_page;
    }

    static SharedPreferences access$17(MainActivity mainActivity) {
        return mainActivity.data;
    }

    static Intent access$12(MainActivity mainActivity) {
        return mainActivity.i;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = MainBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.req_Create = new RequestNetwork(this);
        this.req_login = new RequestNetwork(this);
        this.data = getSharedPreferences("data", 0);
        this.Maintenance = new AlertDialog.Builder(this);
        this.events = new RequestNetwork(this);
        this.binding.ButtonLogin.setOnClickListener(new 1());
        this.binding.buttonCreate.setOnClickListener(new 2());
        this.binding.imageview2.setOnClickListener(new 3());
        this.binding.textview3.setOnClickListener(new 4());
        this._req_Create_request_listener = new 5();
        this._req_login_request_listener = new 6();
        this._events_request_listener = new 7();
    }

    class 1 implements View.OnClickListener {
        1() {
        }

        static MainActivity access$0(1 r1) {
            return MainActivity.this;
        }

        class 1 extends TimerTask {
            1() {
            }

            static 1 access$0(1 r1) {
                return 1.this;
            }

            class 1 implements Runnable {
                1() {
                }

                @Override
                public void run() {
                    MainActivity.access$0(1.access$0(1.access$0(1.this))).buttonCreate.setVisibility(0);
                }
            }

            @Override
            public void run() {
                1.access$0(1.this).runOnUiThread(new 1());
            }
        }

        @Override
        public void onClick(View view) {
            MainActivity.access$0(MainActivity.this).buttonCreate.setVisibility(8);
            MainActivity.access$1(MainActivity.this, new 1());
            MainActivity.access$2(MainActivity.this).schedule(MainActivity.access$3(MainActivity.this), 300L);
            MainActivity.access$0(MainActivity.this).Username.setHint("username");
            MainActivity.access$0(MainActivity.this).Password.setHint("password");
            if (!MainActivity.access$0(MainActivity.this).Username.getText().toString().equals("") || !MainActivity.access$0(MainActivity.this).Password.getText().toString().equals("")) {
                String string = Settings.Secure.getString(MainActivity.this.getContentResolver(), "android_id");
                MainActivity.access$4(MainActivity.this, new HashMap());
                MainActivity.access$5(MainActivity.this).put("username", MainActivity.access$0(MainActivity.this).Username.getText().toString());
                MainActivity.access$5(MainActivity.this).put("password", MainActivity.access$0(MainActivity.this).Password.getText().toString());
                MainActivity.access$5(MainActivity.this).put("device_id", string);
                MainActivity.access$6(MainActivity.this).setParams(MainActivity.access$5(MainActivity.this), 0);
                MainActivity.access$6(MainActivity.this).startRequestNetwork("POST", "https://sors.alwaysdata.net/login", "login account ", MainActivity.access$7(MainActivity.this));
                return;
            }
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setTextColor(-1499549);
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setText("There is a vacuum ؟");
        }
    }

    class 2 implements View.OnClickListener {
        2() {
        }

        @Override
        public void onClick(View view) {
            MainActivity.access$0(MainActivity.this).ButtonLogin.setVisibility(8);
            MainActivity.access$0(MainActivity.this).buttonCreate.setVisibility(0);
            MainActivity.access$0(MainActivity.this).Username.setHint("New username");
            MainActivity.access$0(MainActivity.this).Password.setHint("New password");
            if (!MainActivity.access$0(MainActivity.this).Username.getText().toString().equals("") || !MainActivity.access$0(MainActivity.this).Username.getText().toString().equals("")) {
                String string = Settings.Secure.getString(MainActivity.this.getContentResolver(), "android_id");
                MainActivity.access$8(MainActivity.this, new HashMap());
                MainActivity.access$9(MainActivity.this).put("username", MainActivity.access$0(MainActivity.this).Username.getText().toString());
                MainActivity.access$9(MainActivity.this).put("password", MainActivity.access$0(MainActivity.this).Password.getText().toString());
                MainActivity.access$9(MainActivity.this).put("device_id", string);
                MainActivity.access$10(MainActivity.this).setParams(MainActivity.access$9(MainActivity.this), 0);
                MainActivity.access$10(MainActivity.this).startRequestNetwork("POST", "https://sors.alwaysdata.net/register", "New account ", MainActivity.access$11(MainActivity.this));
                return;
            }
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setTextColor(-1499549);
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setText("There is a vacuum ؟");
        }
    }

    class 3 implements View.OnClickListener {
        3() {
        }

        @Override
        public void onClick(View view) {
            LinearLayout linearLayout = new LinearLayout(MainActivity.this);
            linearLayout.setOrientation(1);
            linearLayout.setPadding(40, 40, 40, 40);
            ImageView imageView = new ImageView(MainActivity.this);
            imageView.setImageResource(R.drawable.usss_3);
            imageView.setLayoutParams(new LinearLayout.LayoutParams(-1, 250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            TextView textView = new TextView(MainActivity.this);
            textView.setTextSize(18.0f);
            textView.setTextColor(-16777216);
            TextView textView2 = new TextView(MainActivity.this);
            textView2.setTextSize(18.0f);
            textView2.setTextColor(-16777216);
            String string = Settings.Secure.getString(MainActivity.this.getContentResolver(), "android_id");
            String str = new SimpleDateFormat("hh:mm a").format(new Date());
            textView.setText("Device ID : " + string);
            textView2.setText("Time : " + str);
            linearLayout.addView(imageView);
            linearLayout.addView(textView);
            linearLayout.addView(textView2);
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Device Info");
            builder.setView(linearLayout);
            builder.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
            builder.show();
        }
    }

    class 4 implements View.OnClickListener {
        4() {
        }

        @Override
        public void onClick(View view) {
            MainActivity.access$12(MainActivity.this).setClass(MainActivity.this.getApplicationContext(), PessActivity.class);
            MainActivity.this.startActivity(MainActivity.access$12(MainActivity.this));
        }
    }

    class 5 implements RequestNetwork.RequestListener {
        5() {
        }

        static MainActivity access$0(5 r1) {
            return MainActivity.this;
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            MainActivity.access$13(MainActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            if (MainActivity.access$14(MainActivity.this).get("status").toString().equals("registered")) {
                MainActivity.access$0(MainActivity.this).textviewResponseMessage.setTextColor(-11751600);
                MainActivity.access$0(MainActivity.this).textviewResponseMessage.setText(MainActivity.access$14(MainActivity.this).get("status").toString());
                MainActivity.access$0(MainActivity.this).buttonCreate.setVisibility(8);
                MainActivity.access$0(MainActivity.this).ButtonLogin.setVisibility(0);
                return;
            }
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setTextColor(-2937041);
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setText(MainActivity.access$14(MainActivity.this).get("status").toString());
            MainActivity.access$0(MainActivity.this).ButtonLogin.setVisibility(0);
            MainActivity.access$1(MainActivity.this, new 2());
            MainActivity.access$2(MainActivity.this).schedule(MainActivity.access$3(MainActivity.this), 300L);
        }

        class 2 extends TimerTask {
            2() {
            }

            static 5 access$0(2 r1) {
                return 5.this;
            }

            class 1 implements Runnable {
                1() {
                }

                @Override
                public void run() {
                    MainActivity.access$0(5.access$0(2.access$0(2.this))).buttonCreate.setVisibility(8);
                }
            }

            @Override
            public void run() {
                5.access$0(5.this).runOnUiThread(new 1());
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 6 implements RequestNetwork.RequestListener {
        6() {
        }

        static MainActivity access$0(6 r1) {
            return MainActivity.this;
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            MainActivity.access$15(MainActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            if (MainActivity.access$16(MainActivity.this).get("status").toString().equals("success")) {
                MainActivity.access$0(MainActivity.this).textviewResponseMessage.setTextColor(-12345273);
                MainActivity.access$0(MainActivity.this).textviewResponseMessage.setText(MainActivity.access$16(MainActivity.this).get("status").toString());
                MainActivity.access$17(MainActivity.this).edit().putString("token", MainActivity.access$16(MainActivity.this).get("token").toString()).commit();
                MainActivity.access$17(MainActivity.this).edit().putString("username", MainActivity.access$16(MainActivity.this).get("username").toString()).commit();
                MainActivity.access$18(MainActivity.this).setClass(MainActivity.this.getApplicationContext(), MenuActivity.class);
                MainActivity.this.startActivity(MainActivity.access$18(MainActivity.this));
                return;
            }
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setTextColor(-769226);
            MainActivity.access$0(MainActivity.this).textviewResponseMessage.setText(MainActivity.access$16(MainActivity.this).get("status").toString());
            MainActivity.access$0(MainActivity.this).ButtonLogin.setVisibility(8);
            MainActivity.access$1(MainActivity.this, new 2());
            MainActivity.access$2(MainActivity.this).schedule(MainActivity.access$3(MainActivity.this), 300L);
        }

        class 2 extends TimerTask {
            2() {
            }

            static 6 access$0(2 r1) {
                return 6.this;
            }

            class 1 implements Runnable {
                1() {
                }

                @Override
                public void run() {
                    MainActivity.access$0(6.access$0(2.access$0(2.this))).buttonCreate.setVisibility(0);
                }
            }

            @Override
            public void run() {
                6.access$0(6.this).runOnUiThread(new 1());
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    class 7 implements RequestNetwork.RequestListener {
        7() {
        }

        static MainActivity access$0(7 r1) {
            return MainActivity.this;
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            try {
                JSONObject jSONObject = new JSONObject(str2);
                if (jSONObject.optBoolean("success", false)) {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("dialog");
                    if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.optBoolean("active", false)) {
                        String strOptString = jSONObjectOptJSONObject.optString("title", "تنبيه");
                        String strOptString2 = jSONObjectOptJSONObject.optString("message", "");
                        String strOptString3 = jSONObjectOptJSONObject.optString("url", "");
                        String strOptString4 = jSONObjectOptJSONObject.optString("image_url", "");
                        jSONObjectOptJSONObject.optBoolean("show_cancel", false);
                        MainActivity.this.runOnUiThread(new 1(strOptString, strOptString2, jSONObjectOptJSONObject.optString("button_confirm", "موافق"), strOptString3, jSONObjectOptJSONObject.optString("button_cancel", "إلغاء"), strOptString4, jSONObjectOptJSONObject.optInt("auto_close", 0)));
                    }
                    JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("maintenance");
                    if (jSONObjectOptJSONObject2 != null && jSONObjectOptJSONObject2.optBoolean("enabled", false)) {
                        boolean zOptBoolean = jSONObjectOptJSONObject2.optBoolean("is_allowed", false);
                        String strOptString5 = jSONObjectOptJSONObject2.optString("message", "التطبيق قيد الصيانة، يرجى المحاولة لاحقاً");
                        String strOptString6 = jSONObjectOptJSONObject2.optString("redirect_url", "");
                        if (!zOptBoolean) {
                            MainActivity.this.runOnUiThread(new 2(strOptString5, strOptString6));
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("API_RESPONSE", e.toString());
            }
        }

        class 1 implements Runnable {
            private final int val$autoClose;
            private final String val$btnCancel;
            private final String val$btnConfirm;
            private final String val$imageUrl;
            private final String val$message;
            private final String val$title;
            private final String val$url;

            1(String str, String str2, String str3, String str4, String str5, String str6, int i) {
                this.val$title = str;
                this.val$message = str2;
                this.val$btnConfirm = str3;
                this.val$url = str4;
                this.val$btnCancel = str5;
                this.val$imageUrl = str6;
                this.val$autoClose = i;
            }

            static 7 access$0(1 r1) {
                return 7.this;
            }

            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(7.access$0(7.this));
                LinearLayout linearLayout = new LinearLayout(7.access$0(7.this));
                linearLayout.setPadding(60, 60, 60, 60);
                linearLayout.setOrientation(1);
                linearLayout.setBackgroundColor(-14803426);
                ImageView imageView = new ImageView(7.access$0(7.this));
                imageView.setVisibility(8);
                linearLayout.addView(imageView);
                TextView textView = new TextView(7.access$0(7.this));
                textView.setText(this.val$title);
                textView.setTextSize(22.0f);
                textView.setTextColor(-1);
                linearLayout.addView(textView);
                TextView textView2 = new TextView(7.access$0(7.this));
                textView2.setText(this.val$message);
                textView2.setTextSize(16.0f);
                textView2.setTextColor(-3355444);
                textView2.setPadding(0, 20, 0, 0);
                linearLayout.addView(textView2);
                builder.setView(linearLayout);
                builder.setCancelable(true);
                builder.setPositiveButton(this.val$btnConfirm, (DialogInterface.OnClickListener) null);
                if (!this.val$url.isEmpty()) {
                    builder.setNegativeButton(this.val$btnCancel, new 1(this.val$url));
                }
                AlertDialog alertDialogCreate = builder.create();
                alertDialogCreate.show();
                if (!this.val$imageUrl.isEmpty()) {
                    new 2(imageView).execute(this.val$imageUrl);
                }
                if (this.val$autoClose > 0) {
                    new Handler().postDelayed(new 3(alertDialogCreate), this.val$autoClose * 1000);
                }
            }

            class 1 implements DialogInterface.OnClickListener {
                private final String val$url;

                1(String str) {
                    this.val$url = str;
                }

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setData(Uri.parse(this.val$url));
                    7.access$0(1.access$0(1.this)).startActivity(intent);
                }
            }

            class 2 extends AsyncTask<String, Void, Bitmap> {
                private final ImageView val$img;

                2(ImageView imageView) {
                    this.val$img = imageView;
                }

                @Override
                public Bitmap doInBackground(String... strArr) {
                    try {
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strArr[0]).openConnection();
                        httpURLConnection.setDoInput(true);
                        httpURLConnection.connect();
                        return BitmapFactory.decodeStream(httpURLConnection.getInputStream());
                    } catch (Exception e) {
                        return null;
                    }
                }

                @Override
                public void onPostExecute(Bitmap bitmap) {
                    if (bitmap != null && this.val$img != null) {
                        this.val$img.setImageBitmap(bitmap);
                        this.val$img.setVisibility(0);
                    }
                }
            }

            class 3 implements Runnable {
                private final AlertDialog val$dialog;

                3(AlertDialog alertDialog) {
                    this.val$dialog = alertDialog;
                }

                @Override
                public void run() {
                    if (this.val$dialog.isShowing()) {
                        this.val$dialog.dismiss();
                    }
                }
            }
        }

        class 2 implements Runnable {
            private final String val$message;
            private final String val$redirectUrl;

            2(String str, String str2) {
                this.val$message = str;
                this.val$redirectUrl = str2;
            }

            static 7 access$0(2 r1) {
                return 7.this;
            }

            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(7.access$0(7.this));
                LinearLayout linearLayout = new LinearLayout(7.access$0(7.this));
                linearLayout.setPadding(100, 100, 100, 100);
                linearLayout.setOrientation(1);
                linearLayout.setBackgroundColor(-16777216);
                TextView textView = new TextView(7.access$0(7.this));
                textView.setText("🔧 وضع الصيانة");
                textView.setTextSize(24.0f);
                textView.setTextColor(-48060);
                TextView textView2 = new TextView(7.access$0(7.this));
                textView2.setText(this.val$message);
                textView2.setTextColor(-1);
                textView2.setPadding(0, 30, 0, 0);
                linearLayout.addView(textView);
                linearLayout.addView(textView2);
                builder.setView(linearLayout);
                builder.setCancelable(false);
                if (!this.val$redirectUrl.isEmpty()) {
                    builder.setPositiveButton("زيارة الموقع", new 1(this.val$redirectUrl));
                    builder.setNegativeButton("خروج", new 2());
                } else {
                    builder.setPositiveButton("خروج", new 3());
                }
                builder.show();
            }

            class 1 implements DialogInterface.OnClickListener {
                private final String val$redirectUrl;

                1(String str) {
                    this.val$redirectUrl = str;
                }

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setData(Uri.parse(this.val$redirectUrl));
                    7.access$0(2.access$0(2.this)).startActivity(intent);
                    7.access$0(2.access$0(2.this)).finishAffinity();
                }
            }

            class 2 implements DialogInterface.OnClickListener {
                2() {
                }

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    7.access$0(2.access$0(2.this)).finishAffinity();
                }
            }

            class 3 implements DialogInterface.OnClickListener {
                3() {
                }

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    7.access$0(2.access$0(2.this)).finishAffinity();
                }
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    private void initializeLogic() {
        this.binding.linear1.setBackgroundColor(-1);
        this.binding.textview1.setText("Log in or create an account");
        this.binding.textview1.setTextSize(18.0f);
        this.binding.textview1.setTextColor(-11184811);
        this.binding.Username.setHint("Username");
        this.binding.Username.setPadding(25, 20, 25, 20);
        this.binding.Username.setTextSize(18.0f);
        this.binding.Username.setBackground(new 8());
        this.binding.Password.setHint("Password");
        this.binding.Password.setPadding(25, 20, 25, 20);
        this.binding.Password.setTextSize(18.0f);
        this.binding.Password.setBackground(new 9());
        this.binding.ButtonLogin.setText("LOGIN");
        this.binding.ButtonLogin.setTextColor(-1);
        this.binding.ButtonLogin.setBackground(new 10());
        this.binding.buttonCreate.setText("CREATE");
        this.binding.buttonCreate.setTextColor(-1);
        this.binding.buttonCreate.setBackground(new 11());
        this.binding.textview3.setText("Forgot Password");
        this.binding.textview3.setPaintFlags(this.binding.textview3.getPaintFlags() | 8);
        this.binding.Username.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_account_circle_round, 0, 0, 0);
        this.binding.Username.setCompoundDrawablePadding(15);
        this.binding.Password.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_enhanced_encryption_round, 0, 0, 0);
        this.binding.Password.setCompoundDrawablePadding(15);
        this.events.startRequestNetwork("GET", "https://sors.alwaysdata.net/api_controller.php?action=events", "", this._events_request_listener);
        this.events.startRequestNetwork("GET", "https://sors.alwaysdata.net/api_controller.php?action=events", "", this._events_request_listener);
        this.events.startRequestNetwork("GET", "https://sors.alwaysdata.net/api_controller.php?action=events", "", this._events_request_listener);
    }

    class 8 extends GradientDrawable {
        8() {
            setColor(-1);
            setCornerRadius(40.0f);
            setStroke(3, -5912923);
        }
    }

    class 9 extends GradientDrawable {
        9() {
            setColor(-1);
            setCornerRadius(40.0f);
            setStroke(3, -5912923);
        }
    }

    class 10 extends GradientDrawable {
        10() {
            setColor(-11567261);
            setCornerRadius(50.0f);
        }
    }

    class 11 extends GradientDrawable {
        11() {
            setColor(-10581592);
            setCornerRadius(50.0f);
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
