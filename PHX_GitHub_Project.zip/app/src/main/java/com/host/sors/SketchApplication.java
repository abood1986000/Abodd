package com.host.sors;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Process;
import android.util.Log;
import java.lang.Thread;

public class SketchApplication extends Application {
    private static Context mApplicationContext;

    public static Context getContext() {
        return mApplicationContext;
    }

    @Override
    public void onCreate() {
        mApplicationContext = getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler(new 1());
        SketchLogger.startLogging();
        super.onCreate();
    }

    class 1 implements Thread.UncaughtExceptionHandler {
        1() {
        }

        @Override
        public void uncaughtException(Thread thread, Throwable th) {
            Intent intent = new Intent(SketchApplication.this.getApplicationContext(), (Class<?>) DebugActivity.class);
            intent.setFlags(268468224);
            intent.putExtra("error", Log.getStackTraceString(th));
            SketchApplication.this.startActivity(intent);
            SketchLogger.broadcastLog(Log.getStackTraceString(th));
            Process.killProcess(Process.myPid());
            System.exit(1);
        }
    }
}
