package com.host.sors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.appbar.AppBarLayout;

public final class MenuBinding {
    public final AppBarLayout AppBar;
    public final CoordinatorLayout Coordinator;
    public final Toolbar Toolbar;
    public final CardView cardview1;
    public final TextView hi;
    public final ImageView imageview1;
    public final LinearLayout linear10;
    public final LinearLayout linear11;
    public final LinearLayout linear2;
    public final LinearLayout linear3;
    public final LinearLayout linear7;
    public final LinearLayout linear9;
    public final ListView listview1;
    public final SwipeRefreshLayout swiperefreshlayout1;
    public final TextView user;

    private MenuBinding(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Toolbar toolbar, LinearLayout linearLayout, SwipeRefreshLayout swipeRefreshLayout, LinearLayout linearLayout2, CardView cardView, LinearLayout linearLayout3, LinearLayout linearLayout4, TextView textView, LinearLayout linearLayout5, TextView textView2, LinearLayout linearLayout6, ImageView imageView, ListView listView) {
        this.Coordinator = coordinatorLayout;
        this.AppBar = appBarLayout;
        this.Toolbar = toolbar;
        this.linear7 = linearLayout;
        this.swiperefreshlayout1 = swipeRefreshLayout;
        this.linear9 = linearLayout2;
        this.cardview1 = cardView;
        this.linear2 = linearLayout3;
        this.linear10 = linearLayout4;
        this.hi = textView;
        this.linear11 = linearLayout5;
        this.user = textView2;
        this.linear3 = linearLayout6;
        this.imageview1 = imageView;
        this.listview1 = listView;
    }

    public CoordinatorLayout getRoot() {
        return this.Coordinator;
    }

    public static MenuBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static MenuBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.menu, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static MenuBinding bind(View view) {
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) view;
        AppBarLayout appBarLayoutFindChildViewById = findChildViewById(view, R.id._app_bar);
        Toolbar toolbarFindChildViewById = findChildViewById(view, R.id._toolbar);
        LinearLayout linearLayout = (LinearLayout) findChildViewById(view, R.id.linear7);
        SwipeRefreshLayout swipeRefreshLayoutFindChildViewById = findChildViewById(view, R.id.swiperefreshlayout1);
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear9);
        CardView cardViewFindChildViewById = findChildViewById(view, R.id.cardview1);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear2);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear10);
        TextView textView = (TextView) findChildViewById(view, R.id.hi);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear11);
        TextView textView2 = (TextView) findChildViewById(view, R.id.user);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear3);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imageview1);
        ListView listView = (ListView) findChildViewById(view, R.id.listview1);
        if (appBarLayoutFindChildViewById == null || toolbarFindChildViewById == null || linearLayout == null || swipeRefreshLayoutFindChildViewById == null || linearLayout2 == null || cardViewFindChildViewById == null || linearLayout3 == null || linearLayout4 == null || textView == null || linearLayout5 == null || textView2 == null || linearLayout6 == null || imageView == null || listView == null) {
            throw new IllegalStateException("Required views are missing");
        }
        return new MenuBinding(coordinatorLayout, appBarLayoutFindChildViewById, toolbarFindChildViewById, linearLayout, swipeRefreshLayoutFindChildViewById, linearLayout2, cardViewFindChildViewById, linearLayout3, linearLayout4, textView, linearLayout5, textView2, linearLayout6, imageView, listView);
    }

    private static <T extends View> View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }
}
