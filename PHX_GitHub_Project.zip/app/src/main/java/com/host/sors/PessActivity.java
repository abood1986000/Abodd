package com.host.sors;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.host.sors.RequestNetwork;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class PessActivity extends AppCompatActivity {
    private RequestNetwork.RequestListener _rest_request_listener;
    private PessBinding binding;
    private RequestNetwork rest;
    private HashMap restMap = new HashMap();
    private String deviceId = "";

    static PessBinding access$0(PessActivity pessActivity) {
        return pessActivity.binding;
    }

    static void access$1(PessActivity pessActivity, HashMap map) {
        pessActivity.restMap = map;
    }

    static HashMap access$2(PessActivity pessActivity) {
        return pessActivity.restMap;
    }

    static RequestNetwork access$3(PessActivity pessActivity) {
        return pessActivity.rest;
    }

    static RequestNetwork.RequestListener access$4(PessActivity pessActivity) {
        return pessActivity._rest_request_listener;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.binding = PessBinding.inflate(getLayoutInflater());
        setContentView(this.binding.getRoot());
        initialize(bundle);
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.rest = new RequestNetwork(this);
        this.binding.Send.setOnClickListener(new 1());
        this._rest_request_listener = new 2();
    }

    class 1 implements View.OnClickListener {
        1() {
        }

        @Override
        public void onClick(View view) {
            if (!PessActivity.access$0(PessActivity.this).email.getText().toString().equals("")) {
                String string = Settings.Secure.getString(PessActivity.this.getContentResolver(), "android_id");
                PessActivity.access$1(PessActivity.this, new HashMap());
                PessActivity.access$2(PessActivity.this).put("device_id", string);
                PessActivity.access$2(PessActivity.this).put("email", PessActivity.access$0(PessActivity.this).email.getText().toString());
                PessActivity.access$3(PessActivity.this).setParams(PessActivity.access$2(PessActivity.this), 0);
                PessActivity.access$3(PessActivity.this).startRequestNetwork("POST", "https://sors.alwaysdata.net/forgot", "", PessActivity.access$4(PessActivity.this));
                return;
            }
            PessActivity.access$0(PessActivity.this).message.setTextColor(-3790808);
            PessActivity.access$0(PessActivity.this).message.setText("Enter your mail");
        }
    }

    class 2 implements RequestNetwork.RequestListener {
        2() {
        }

        class 1 extends TypeToken<HashMap<String, Object>> {
            1() {
            }
        }

        @Override
        public void onResponse(String str, String str2, HashMap map) {
            PessActivity.access$1(PessActivity.this, (HashMap) new Gson().fromJson(str2, new 1().getType()));
            if (PessActivity.access$2(PessActivity.this).get("status").toString().equals("sent")) {
                PessActivity.access$0(PessActivity.this).message.setTextColor(-13730510);
                PessActivity.access$0(PessActivity.this).message.setText(PessActivity.access$2(PessActivity.this).get("message").toString());
                SketchwareUtil.showMessage(PessActivity.this.getApplicationContext(), PessActivity.access$2(PessActivity.this).get("message").toString());
            } else {
                PessActivity.access$0(PessActivity.this).message.setTextColor(-1499549);
                PessActivity.access$0(PessActivity.this).message.setText(PessActivity.access$2(PessActivity.this).get("message").toString());
                SketchwareUtil.showMessage(PessActivity.this.getApplicationContext(), PessActivity.access$2(PessActivity.this).get("message").toString());
            }
        }

        @Override
        public void onErrorResponse(String str, String str2) {
        }
    }

    private void initializeLogic() {
        this.binding.email.setPadding(25, 20, 25, 20);
        this.binding.email.setTextSize(18.0f);
        this.binding.email.setBackground(new 3());
        this.binding.email.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_alternate_email_round, 0, 0, 0);
        this.binding.email.setCompoundDrawablePadding(15);
        this.binding.Send.setTextColor(-1);
        this.binding.Send.setBackground(new 4());
    }

    class 3 extends GradientDrawable {
        3() {
            setColor(-1);
            setCornerRadius(40.0f);
            setStroke(3, -5912923);
        }
    }

    class 4 extends GradientDrawable {
        4() {
            setColor(-11567261);
            setCornerRadius(50.0f);
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
