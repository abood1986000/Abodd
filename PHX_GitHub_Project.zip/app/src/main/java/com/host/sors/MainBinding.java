package com.host.sors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainBinding {
    public final Button ButtonLogin;
    public final EditText Password;
    public final EditText Username;
    public final Button buttonCreate;
    public final ImageView imageview1;
    public final ImageView imageview2;
    public final LinearLayout linear1;
    public final LinearLayout linear2;
    public final LinearLayout linear3;
    public final LinearLayout linear4;
    public final LinearLayout linear5;
    public final LinearLayout linear6;
    public final LinearLayout linear7;
    public final LinearLayout rootView;
    public final TextView textview1;
    public final TextView textview2;
    public final TextView textview3;
    public final TextView textviewResponseMessage;

    private MainBinding(LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, TextView textView, LinearLayout linearLayout4, TextView textView2, ImageView imageView, EditText editText, LinearLayout linearLayout5, EditText editText2, LinearLayout linearLayout6, Button button, LinearLayout linearLayout7, Button button2, LinearLayout linearLayout8, TextView textView3, ImageView imageView2, TextView textView4) {
        this.rootView = linearLayout;
        this.linear1 = linearLayout2;
        this.linear2 = linearLayout3;
        this.textview1 = textView;
        this.linear7 = linearLayout4;
        this.textview2 = textView2;
        this.imageview2 = imageView;
        this.Username = editText;
        this.linear4 = linearLayout5;
        this.Password = editText2;
        this.linear6 = linearLayout6;
        this.ButtonLogin = button;
        this.linear3 = linearLayout7;
        this.buttonCreate = button2;
        this.linear5 = linearLayout8;
        this.textview3 = textView3;
        this.imageview1 = imageView2;
        this.textviewResponseMessage = textView4;
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }

    public static MainBinding inflate(LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    public static MainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.main, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    public static MainBinding bind(View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        LinearLayout linearLayout2 = (LinearLayout) findChildViewById(view, R.id.linear1);
        LinearLayout linearLayout3 = (LinearLayout) findChildViewById(view, R.id.linear2);
        TextView textView = (TextView) findChildViewById(view, R.id.textview1);
        LinearLayout linearLayout4 = (LinearLayout) findChildViewById(view, R.id.linear7);
        TextView textView2 = (TextView) findChildViewById(view, R.id.textview2);
        ImageView imageView = (ImageView) findChildViewById(view, R.id.imageview2);
        EditText editText = (EditText) findChildViewById(view, R.id.Username);
        LinearLayout linearLayout5 = (LinearLayout) findChildViewById(view, R.id.linear4);
        EditText editText2 = (EditText) findChildViewById(view, R.id.Password);
        LinearLayout linearLayout6 = (LinearLayout) findChildViewById(view, R.id.linear6);
        Button button = (Button) findChildViewById(view, R.id.Button_login);
        LinearLayout linearLayout7 = (LinearLayout) findChildViewById(view, R.id.linear3);
        Button button2 = (Button) findChildViewById(view, R.id.button_Create);
        LinearLayout linearLayout8 = (LinearLayout) findChildViewById(view, R.id.linear5);
        TextView textView3 = (TextView) findChildViewById(view, R.id.textview3);
        ImageView imageView2 = (ImageView) findChildViewById(view, R.id.imageview1);
        TextView textView4 = (TextView) findChildViewById(view, R.id.textview_Response_message);
        if (linearLayout2 == null || linearLayout3 == null || textView == null || linearLayout4 == null || textView2 == null || imageView == null || editText == null || linearLayout5 == null || editText2 == null || linearLayout6 == null || button == null || linearLayout7 == null || button2 == null || linearLayout8 == null || textView3 == null || imageView2 == null || textView4 == null) {
            throw new IllegalStateException("Required views are missing");
        }
        return new MainBinding(linearLayout, linearLayout2, linearLayout3, textView, linearLayout4, textView2, imageView, editText, linearLayout5, editText2, linearLayout6, button, linearLayout7, button2, linearLayout8, textView3, imageView2, textView4);
    }

    private static <T extends View> View findChildViewById(View view, int i) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View viewFindViewById = viewGroup.getChildAt(i2).findViewById(i);
                if (viewFindViewById != null) {
                    return viewFindViewById;
                }
            }
        }
        return null;
    }
}
