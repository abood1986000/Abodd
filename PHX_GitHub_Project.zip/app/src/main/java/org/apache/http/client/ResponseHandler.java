package org.apache.http.client;

import java.io.IOException;
import org.apache.http.HttpResponse;

@Deprecated
public interface ResponseHandler<T> {
    Object handleResponse(HttpResponse httpResponse) throws IOException;
}
