package org.apache.http.cookie;

import java.io.Serializable;
import java.util.Comparator;

@Deprecated
public class CookiePathComparator implements Serializable, Comparator<Cookie> {
    public CookiePathComparator() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int compare(Cookie c1, Cookie c2) {
        throw new RuntimeException("Stub!");
    }
}
