package org.apache.http.impl.client;

import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ResponseHandler;

@Deprecated
public class BasicResponseHandler implements ResponseHandler<String> {
    public BasicResponseHandler() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String handleResponse(HttpResponse response) throws IOException {
        throw new RuntimeException("Stub!");
    }
}
