package org.apache.http.client.methods;

import java.net.URI;

@Deprecated
public class HttpTrace extends HttpRequestBase {
    public static final String METHOD_NAME = "TRACE";

    public HttpTrace() {
        throw new RuntimeException("Stub!");
    }

    public HttpTrace(URI uri) {
        throw new RuntimeException("Stub!");
    }

    public HttpTrace(String uri) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getMethod() {
        throw new RuntimeException("Stub!");
    }
}
