package org.apache.http.message;

import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpMessage;
import org.apache.http.params.HttpParams;

@Deprecated
public abstract class AbstractHttpMessage implements HttpMessage {
    protected HeaderGroup headergroup;
    protected HttpParams params;

    protected AbstractHttpMessage(HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    protected AbstractHttpMessage() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean containsHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header[] getHeaders(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header getFirstHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header getLastHeader(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header[] getAllHeaders() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void addHeader(Header header) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void addHeader(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setHeader(Header header) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setHeader(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setHeaders(Header[] headers) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void removeHeader(Header header) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void removeHeaders(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public HeaderIterator headerIterator() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public HeaderIterator headerIterator(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public HttpParams getParams() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setParams(HttpParams params) {
        throw new RuntimeException("Stub!");
    }
}
