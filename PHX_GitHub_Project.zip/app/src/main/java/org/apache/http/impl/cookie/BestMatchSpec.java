package org.apache.http.impl.cookie;

import java.util.List;
import org.apache.http.Header;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.CookieSpec;
import org.apache.http.cookie.MalformedCookieException;

@Deprecated
public class BestMatchSpec implements CookieSpec {
    public BestMatchSpec(String[] datepatterns, boolean oneHeader) {
        throw new RuntimeException("Stub!");
    }

    public BestMatchSpec() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public List parse(Header header, CookieOrigin origin) throws MalformedCookieException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void validate(Cookie cookie, CookieOrigin origin) throws MalformedCookieException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean match(Cookie cookie, CookieOrigin origin) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public List formatCookies(List list) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getVersion() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header getVersionHeader() {
        throw new RuntimeException("Stub!");
    }
}
