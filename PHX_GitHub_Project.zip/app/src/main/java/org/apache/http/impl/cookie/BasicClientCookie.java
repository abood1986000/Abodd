package org.apache.http.impl.cookie;

import java.util.Date;
import org.apache.http.cookie.ClientCookie;
import org.apache.http.cookie.SetCookie;

@Deprecated
public class BasicClientCookie implements SetCookie, ClientCookie {
    public BasicClientCookie(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getName() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getValue() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setValue(String value) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getComment() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setComment(String comment) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getCommentURL() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Date getExpiryDate() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setExpiryDate(Date expiryDate) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isPersistent() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getDomain() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setDomain(String domain) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getPath() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setPath(String path) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isSecure() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setSecure(boolean secure) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int[] getPorts() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getVersion() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void setVersion(int version) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isExpired(Date date) {
        throw new RuntimeException("Stub!");
    }

    public void setAttribute(String name, String value) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getAttribute(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean containsAttribute(String name) {
        throw new RuntimeException("Stub!");
    }

    public Object clone() throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }

    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
