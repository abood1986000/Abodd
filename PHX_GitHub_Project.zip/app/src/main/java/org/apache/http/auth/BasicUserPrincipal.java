package org.apache.http.auth;

import java.security.Principal;

@Deprecated
public final class BasicUserPrincipal implements Principal {
    public BasicUserPrincipal(String username) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getName() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int hashCode() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean equals(Object o) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String toString() {
        throw new RuntimeException("Stub!");
    }
}
