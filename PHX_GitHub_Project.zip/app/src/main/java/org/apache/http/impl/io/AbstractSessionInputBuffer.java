package org.apache.http.impl.io;

import java.io.IOException;
import java.io.InputStream;
import org.apache.http.io.HttpTransportMetrics;
import org.apache.http.io.SessionInputBuffer;
import org.apache.http.params.HttpParams;
import org.apache.http.util.CharArrayBuffer;

@Deprecated
public abstract class AbstractSessionInputBuffer implements SessionInputBuffer {
    public AbstractSessionInputBuffer() {
        throw new RuntimeException("Stub!");
    }

    protected void init(InputStream instream, int buffersize, HttpParams params) {
        throw new RuntimeException("Stub!");
    }

    protected int fillBuffer() throws IOException {
        throw new RuntimeException("Stub!");
    }

    protected boolean hasBufferedData() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int read() throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int read(byte[] b) throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int readLine(CharArrayBuffer charbuffer) throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String readLine() throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public HttpTransportMetrics getMetrics() {
        throw new RuntimeException("Stub!");
    }
}
