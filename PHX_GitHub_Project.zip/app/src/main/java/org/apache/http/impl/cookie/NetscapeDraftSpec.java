package org.apache.http.impl.cookie;

import java.util.List;
import org.apache.http.Header;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.MalformedCookieException;

@Deprecated
public class NetscapeDraftSpec extends CookieSpecBase {
    protected static final String EXPIRES_PATTERN = "EEE, dd-MMM-yyyy HH:mm:ss z";

    public NetscapeDraftSpec(String[] datepatterns) {
        throw new RuntimeException("Stub!");
    }

    public NetscapeDraftSpec() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public List parse(Header header, CookieOrigin origin) throws MalformedCookieException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public List formatCookies(List list) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getVersion() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header getVersionHeader() {
        throw new RuntimeException("Stub!");
    }
}
