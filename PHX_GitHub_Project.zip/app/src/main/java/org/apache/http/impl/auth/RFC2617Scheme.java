package org.apache.http.impl.auth;

import java.util.Map;
import org.apache.http.auth.MalformedChallengeException;
import org.apache.http.util.CharArrayBuffer;

@Deprecated
public abstract class RFC2617Scheme extends AuthSchemeBase {
    public RFC2617Scheme() {
        throw new RuntimeException("Stub!");
    }

    @Override
    protected void parseChallenge(CharArrayBuffer buffer, int pos, int len) throws MalformedChallengeException {
        throw new RuntimeException("Stub!");
    }

    protected Map getParameters() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getParameter(String name) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String getRealm() {
        throw new RuntimeException("Stub!");
    }
}
