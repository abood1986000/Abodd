package org.apache.http.entity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

@Deprecated
public class ByteArrayEntity extends AbstractHttpEntity {
    protected final byte[] content = null;

    public ByteArrayEntity(byte[] b) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isRepeatable() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public long getContentLength() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public InputStream getContent() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public void writeTo(OutputStream outstream) throws IOException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean isStreaming() {
        throw new RuntimeException("Stub!");
    }

    public Object clone() throws CloneNotSupportedException {
        throw new RuntimeException("Stub!");
    }
}
