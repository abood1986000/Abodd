package org.apache.http.impl.cookie;

import java.util.List;
import org.apache.http.Header;
import org.apache.http.cookie.CookieOrigin;
import org.apache.http.cookie.MalformedCookieException;

@Deprecated
public class BrowserCompatSpec extends CookieSpecBase {
    protected static final String[] DATE_PATTERNS = null;

    public BrowserCompatSpec(String[] datepatterns) {
        throw new RuntimeException("Stub!");
    }

    public BrowserCompatSpec() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public List parse(Header header, CookieOrigin origin) throws MalformedCookieException {
        throw new RuntimeException("Stub!");
    }

    @Override
    public List formatCookies(List list) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int getVersion() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public Header getVersionHeader() {
        throw new RuntimeException("Stub!");
    }
}
